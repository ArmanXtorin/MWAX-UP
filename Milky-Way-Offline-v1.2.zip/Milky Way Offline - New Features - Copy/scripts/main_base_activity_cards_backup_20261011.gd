extends Control

const TIER_NAMES := ["Wooden", "Stone", "Copper", "Iron", "Golden", "Diamond"]
const TIER_TIMES := [5.0, 7.0, 13.0, 20.0, 30.0, 60.0]
const RESOURCE_NAMES := ["Stone", "Copper", "Iron", "Gold", "Diamond"]
const WOOD_NAMES := ["Oak Wood", "Birch Wood", "Spruce Wood", "Dark Oak Wood", "Redwood"]
const EQUIPMENT_TYPES := ["Pickaxe", "Axe", "Pan", "Sword", "Mace", "Shield", "Helmet", "Body Armor", "Leg Armor", "Knee Armor"]

var coins: int = 0
var unlocked_tier: int = 0
var active_action: String = ""
var active_total: float = 0.0
var active_elapsed: float = 0.0
var active_mode: String = "one"
var active_kind: String = ""
var active_index: int = 0
var active_recipe: Dictionary = {}
var inventory: Dictionary = {}
var crafted_equipment: Dictionary = {}
var equipped: Dictionary = {"Pickaxe":"", "Axe":"", "Pan":"", "Weapon":"", "Shield":"", "Helmet":"", "Body Armor":"", "Leg Armor":"", "Knee Armor":""}
var stats := {"mined":0, "wood_cut":0, "crafted":0}
var resource_buy := [10, 20, 50, 100, 500]
var resource_sell := [5, 10, 20, 50, 200]
var wood_buy := [10, 20, 50, 100, 200]
var wood_sell := [5, 10, 20, 50, 100]
var food_prices := {"Apple":[50,20], "Bread":[100,50], "Cooked Potato":[300,100], "Cooked Chicken":[500,200], "Steak":[1000,400], "Royal Feast":[2000,700]}

var content: VBoxContainer
var coins_label: Label
var status_label: Label
var progress: ProgressBar
var dialog: AcceptDialog

func _ready() -> void:
	for item in RESOURCE_NAMES + WOOD_NAMES:
		inventory[item] = 0
	for food in food_prices:
		inventory[food] = 0
	build_ui()
	show_page("Mining")

func _item_icon(item: String) -> Texture2D:
	var paths: Dictionary = {
		"Stone": "res://assets/icons/items/stone.svg",
		"Copper": "res://assets/icons/items/copper.svg",
		"Iron": "res://assets/icons/items/iron.svg",
		"Gold": "res://assets/icons/items/gold.svg",
		"Diamond": "res://assets/icons/items/diamond.svg",
		"Oak Wood": "res://assets/icons/items/oak_wood.svg",
		"Birch Wood": "res://assets/icons/items/birch_wood.svg",
		"Spruce Wood": "res://assets/icons/items/spruce_wood.svg",
		"Dark Oak Wood": "res://assets/icons/items/dark_oak_wood.svg",
		"Redwood": "res://assets/icons/items/redwood.svg"
	}
	var path_value: String = str(paths.get(item, ""))
	if path_value == "":
		return null
	return load(path_value) as Texture2D

func _nav_icon(page: String) -> Texture2D:
	var paths: Dictionary = {
		"Mining": "res://assets/icons/mining.svg",
		"Woodcutting": "res://assets/icons/woodcutting.svg",
		"Blacksmith": "res://assets/icons/blacksmith.svg",
		"Smelting": "res://assets/icons/smelting.svg",
		"Shop": "res://assets/icons/shop.svg",
		"Food": "res://assets/icons/food.svg",
		"Inventory": "res://assets/icons/inventory.svg",
		"Settings": "res://assets/icons/settings.svg"
	}
	var path_value: String = str(paths.get(page, ""))
	if path_value == "":
		return null
	return load(path_value) as Texture2D

func build_ui() -> void:
	var bg := ColorRect.new()
	bg.color = Color("#11151c")
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var margin := MarginContainer.new()
	margin.name = "MainUIRoot"
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for side in ["left","right","top","bottom"]:
		margin.add_theme_constant_override("margin_" + side, 20)
	add_child(margin)
	var main := VBoxContainer.new()
	main.add_theme_constant_override("separation", 10)
	margin.add_child(main)
	var header := HBoxContainer.new()
	main.add_child(header)
	var title := Label.new()
	title.text = "MILKY WAY"
	title.add_theme_font_size_override("font_size", 28)
	header.add_child(title)
	coins_label = Label.new()
	coins_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	coins_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	header.add_child(coins_label)
	var body := HBoxContainer.new()
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 14)
	main.add_child(body)
	var sidebar_scroll := ScrollContainer.new()
	sidebar_scroll.name = "SidebarScroll"
	sidebar_scroll.custom_minimum_size = Vector2(205, 0)
	sidebar_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sidebar_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	body.add_child(sidebar_scroll)
	var sidebar := VBoxContainer.new()
	sidebar.custom_minimum_size = Vector2(190, 0)
	sidebar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sidebar.add_theme_constant_override("separation", 6)
	sidebar_scroll.add_child(sidebar)
	var side_title := Label.new()
	side_title.text = "ACTIVITY"
	side_title.add_theme_font_size_override("font_size", 16)
	sidebar.add_child(side_title)
	for page in ["Mining","Woodcutting","Blacksmith","Smelting","Shop","Food","Inventory","Settings"]:
		var b := Button.new()
		b.text = page
		b.custom_minimum_size = Vector2(180, 44)
		b.icon = _nav_icon(page)
		b.expand_icon = true
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.pressed.connect(func() -> void: show_page(page))
		sidebar.add_child(b)
	var skill_title := Label.new()
	skill_title.text = "SKILLS"
	skill_title.add_theme_font_size_override("font_size", 16)
	sidebar.add_child(HSeparator.new())
	sidebar.add_child(skill_title)
	var levels: Dictionary = get("skill_levels") if get("skill_levels") is Dictionary else {}
	for skill in ["Mining","Woodcutting","Blacksmithing"]:
		var skill_box := VBoxContainer.new()
		skill_box.add_theme_constant_override("separation", 2)
		var skill_label := Label.new()
		skill_label.name = "SkillLabel_" + skill
		skill_label.text = skill + " Lv. " + str(levels.get(skill, 1))
		skill_box.add_child(skill_label)
		var skill_bar := ProgressBar.new()
		skill_bar.name = "SkillBar_" + skill
		skill_bar.min_value = 0
		skill_bar.max_value = 100
		skill_bar.value = 0
		skill_bar.custom_minimum_size = Vector2(0, 14)
		skill_bar.show_percentage = false
		skill_box.add_child(skill_bar)
		sidebar.add_child(skill_box)
	var scroll := ScrollContainer.new()
	scroll.name = "ContentScroll"
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	body.add_child(scroll)
	content = VBoxContainer.new()
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.add_theme_constant_override("separation", 8)
	content.custom_minimum_size = Vector2(0, 0)
	scroll.add_child(content)
	status_label = Label.new()
	main.add_child(status_label)
	progress = ProgressBar.new()
	progress.visible = false
	main.add_child(progress)
	dialog = AcceptDialog.new()
	dialog.title = "Milky Way"
	add_child(dialog)
	update_coins()

func clear_content() -> void:
	for child in content.get_children(): child.queue_free()

func heading(text: String) -> void:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", 22)
	content.add_child(l)

func add_tabs(names: Array, callback: Callable) -> void:
	var row := HBoxContainer.new()
	for tab_name in names:
		var b := Button.new()
		b.text = str(tab_name)
		var name := str(tab_name)
		b.pressed.connect(func() -> void: callback.call(name))
		row.add_child(b)
	content.add_child(row)
	content.add_child(HSeparator.new())

func show_page(page: String) -> void:
	if page == "Settings" and has_method("show_settings"):
		call("show_settings")
		return
	if page == "Smelting" and has_method("show_smelting"):
		call("show_smelting")
		return
	clear_content()
	match page:
		"Mining": show_mining()
		"Woodcutting": show_woodcutting()
		"Blacksmith": show_blacksmith()
		"Shop": show_shop("Resources")
		"Food": show_food()
		"Inventory": show_inventory("Resources")

func _resource_level_requirement(index: int) -> int:
	return [1, 15, 25, 30, 50][clamp(index, 0, 4)]

func _wood_level_requirement(index: int) -> int:
	return [1, 15, 25, 30, 50][clamp(index, 0, 4)]

func _resource_level_unlocked(index: int) -> bool:
	if not has_method("_new_skill_level"):
		return true
	return int(call("_new_skill_level", "Mining")) >= _resource_level_requirement(index)

func _wood_level_unlocked(index: int) -> bool:
	if not has_method("_new_skill_level"):
		return true
	return int(call("_new_skill_level", "Woodcutting")) >= _wood_level_requirement(index)

func show_mining() -> void:
	heading("Mining")
	var grid := GridContainer.new()
	grid.columns = 3
	content.add_child(grid)
	for i in range(RESOURCE_NAMES.size()):
		var b := Button.new()
		b.custom_minimum_size = Vector2(150,150)
		b.text = RESOURCE_NAMES[i] + "\n" + str(TIER_TIMES[i + 1]) + "s\nRequires Mining Lv. " + str(_resource_level_requirement(i))
		b.icon = _item_icon(RESOURCE_NAMES[i])
		b.expand_icon = true
		b.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
		b.disabled = not _resource_level_unlocked(i)
		var idx := i
		b.pressed.connect(func() -> void: ask_mode(RESOURCE_NAMES[idx], TIER_TIMES[idx + 1], "mining", idx))
		grid.add_child(b)
	add_cancel_button()

func show_woodcutting() -> void:
	heading("Woodcutting")
	var grid := GridContainer.new()
	grid.columns = 3
	content.add_child(grid)
	for i in range(WOOD_NAMES.size()):
		var b := Button.new()
		b.custom_minimum_size = Vector2(150,150)
		b.text = WOOD_NAMES[i] + "\n" + str(TIER_TIMES[i]) + "s\nRequires Woodcutting Lv. " + str(_wood_level_requirement(i))
		b.icon = _item_icon(WOOD_NAMES[i])
		b.expand_icon = true
		b.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
		b.disabled = not _wood_level_unlocked(i)
		var idx := i
		b.pressed.connect(func() -> void: ask_mode(WOOD_NAMES[idx], TIER_TIMES[idx], "wood", idx))
		grid.add_child(b)
	add_cancel_button()

func show_blacksmith() -> void:
	heading("Blacksmith - " + TIER_NAMES[unlocked_tier] + " Tier")
	var info := Label.new()
	info.text = "Select an item to see crafting time, required materials, and your current materials."
	content.add_child(info)
	for item_type in EQUIPMENT_TYPES:
		var b := Button.new()
		b.text = TIER_NAMES[unlocked_tier] + " " + item_type
		var t := str(item_type) 
func show_recipe(recipe: Dictionary) -> void:
	clear_content()
	heading(str(recipe["name"]))
	var time_label := Label.new()
	time_label.text = "Crafting time: " + str(recipe["time"]) + " seconds"
	content.add_child(time_label)
	var req_title := Label.new()
	req_title.text = "REQUIRED MATERIALS (You have / Need)"
	content.add_child(req_title)
	var can_craft := true
	for key in recipe["materials"]:
		var need: int = int(recipe["materials"][key])
		if need <= 0: continue
		var have: int = int(inventory.get(key, 0))
		var l := Label.new()
		l.text = str(key) + ": " + str(have) + " / " + str(need)
		content.add_child(l)
		if have < need: can_craft = false
	var result := Label.new()
	result.text = "RESULT: +1 " + str(recipe["name"])
	content.add_child(result)
	var once := Button.new()
	once.text = "Craft Once"
	once.disabled = not can_craft
	once.pressed.connect(func() -> void: ask_craft_mode(recipe, "one"))
	content.add_child(once)
	var infinite := Button.new()
	infinite.text = "Craft Infinite (until materials run out)"
	infinite.disabled = not can_craft
	infinite.pressed.connect(func() -> void: ask_craft_mode(recipe, "infinite"))
	content.add_child(infinite)
	var back := Button.new()
	back.text = "Back"
	back.pressed.connect(show_blacksmith)
	content.add_child(back)

func ask_mode(action_name: String, seconds: float, kind: String, index: int) -> void:
	if active_action != "":
		status_label.text = "Finish or cancel the current operation first."
		return
	var box := VBoxContainer.new()
	var label := Label.new()
	label.text = action_name + "\nChoose operation mode"
	box.add_child(label)
	var one := Button.new()
	one.text = "One Time"
	one.pressed.connect(func() -> void:
		dialog.hide(); box.queue_free(); start_action(action_name, seconds, "one", kind, index))
	box.add_child(one)
	var infinite := Button.new()
	infinite.text = "Infinite"
	infinite.pressed.connect(func() -> void:
		dialog.hide(); box.queue_free(); start_action(action_name, seconds, "infinite", kind, index))
	box.add_child(infinite)
	dialog.add_child(box)
	dialog.popup_centered(Vector2(360,220))

func ask_craft_mode(recipe: Dictionary, mode: String) -> void:
	if active_action != "": return
	active_recipe = recipe
	start_action(str(recipe["name"]), float(recipe["time"]), mode, "craft", 0)

func start_action(name: String, seconds: float, mode: String, kind: String, index: int) -> void:
	active_action = name
	active_total = seconds
	active_elapsed = 0.0
	active_mode = mode
	active_kind = kind
	active_index = index
	progress.visible = true
	progress.max_value = 100.0
	progress.value = 0.0
	status_label.text = name + " started."

func has_recipe_materials(recipe: Dictionary) -> bool:
	for key in recipe["materials"]:
		if int(recipe["materials"][key]) > int(inventory.get(key, 0)): return false
	return true

func consume_recipe(recipe: Dictionary) -> void:
	for key in recipe["materials"]:
		var need: int = int(recipe["materials"][key])
		inventory[key] = int(inventory.get(key, 0)) - need

func complete_operation() -> void:
	if active_kind == "mining":
		var item: String = RESOURCE_NAMES[active_index]
		inventory[item] = int(inventory.get(item, 0)) + 1
		stats["mined"] = int(stats["mined"]) + 1

	elif active_kind == "wood":
		var item: String = WOOD_NAMES[active_index]
		inventory[item] = int(inventory.get(item, 0)) + 1
		stats["wood_cut"] = int(stats["wood_cut"]) + 1

	elif active_kind == "craft":
		if not has_recipe_materials(active_recipe):
			stop_action("Materials ran out.")
			return
		consume_recipe(active_recipe)
		var name := str(active_recipe["name"])
		inventory[name] = int(inventory.get(name,0)) + 1
		crafted_equipment[name] = true
		stats["crafted"] = int(stats["crafted"]) + 1
		check_tier_unlock()
	status_label.text = active_action + " completed."
	if active_mode == "infinite":
		if active_kind == "craft" and not has_recipe_materials(active_recipe):
			stop_action("Materials ran out.")
		else:
			active_elapsed = 0.0
			progress.value = 0.0
	else:
		stop_action(status_label.text)

func check_tier_unlock() -> void:
	if unlocked_tier >= TIER_NAMES.size() - 1:
		return

	for item_type in EQUIPMENT_TYPES:
		var item_name: String = TIER_NAMES[unlocked_tier] + " " + item_type
		if int(inventory.get(item_name, 0)) <= 0:
			return

	unlocked_tier += 1
	status_label.text = "Tier completed! " + TIER_NAMES[unlocked_tier] + " Tier unlocked!"

func stop_action(message: String) -> void:
	active_action = ""
	active_kind = ""
	active_recipe = {}
	progress.visible = false
	status_label.text = message

func cancel_action() -> void:
	if active_action != "": stop_action("Operation cancelled.")

func add_cancel_button() -> void:
	var b := Button.new()
	b.text = "Cancel Current Operation"
	b.pressed.connect(cancel_action)
	content.add_child(b)

func show_shop(tab: String) -> void:
	clear_content()
	heading("Shop")
	add_tabs(["Resources","Wood","Equipment","Food"], func(name: String) -> void: show_shop(name))
	if tab == "Resources": show_shop_resources()
	elif tab == "Wood": show_shop_wood()
	elif tab == "Equipment": show_shop_equipment()
	else: show_shop_food()

func shop_row(name: String, buy_price: int, sell_price: int, buy_callback: Callable, sell_callback: Callable) -> void:
	var row := HBoxContainer.new()
	var l := Label.new()
	var owned_text := str(inventory.get(name, 0))
	var buy_text := str(buy_price)
	var sell_text := str(sell_price)
	if has_method("_format_setting_number"):
		owned_text = str(call("_format_setting_number", int(inventory.get(name, 0))))
		buy_text = str(call("_format_setting_number", buy_price))
		sell_text = str(call("_format_setting_number", sell_price))
	l.text = name + "  Own: " + owned_text
	l.custom_minimum_size = Vector2(220,40)
	row.add_child(l)
	var buy := Button.new()
	buy.text = "Buy " + buy_text
	buy.pressed.connect(buy_callback)
	row.add_child(buy)
	var sell := Button.new()
	sell.text = "Sell " + sell_text
	sell.pressed.connect(sell_callback)
	row.add_child(sell)
	content.add_child(row)

func show_shop_resources() -> void:
	for i in range(RESOURCE_NAMES.size()):
		var idx := i
		shop_row(RESOURCE_NAMES[i], resource_buy[i], resource_sell[i], func() -> void: buy_item(RESOURCE_NAMES[idx], resource_buy[idx]), func() -> void: sell_item(RESOURCE_NAMES[idx], resource_sell[idx]))

func show_shop_wood() -> void:
	for i in range(WOOD_NAMES.size()):
		var idx := i
		shop_row(WOOD_NAMES[i], wood_buy[i], wood_sell[i], func() -> void: buy_item(WOOD_NAMES[idx], wood_buy[idx]), func() -> void: sell_item(WOOD_NAMES[idx], wood_sell[idx]))

func show_shop_equipment() -> void:
	for tier in range(unlocked_tier + 1):
		for item_type in EQUIPMENT_TYPES:
			var item_name: String = TIER_NAMES[tier] + " " + item_type
			var buy_price: int = int(100 * (tier + 1) * 1.7)
			var sell_price: int = int(buy_price / 2)

			shop_row(
				item_name,
				buy_price,
				sell_price,
				func() -> void:
					buy_item(item_name, buy_price),
				func() -> void:
					sell_item(item_name, sell_price)
			)

func show_shop_food() -> void:
	for food_name in food_prices:
		var p: Array = food_prices[food_name]
		var name := str(food_name)
		shop_row(name, int(p[0]), int(p[1]), func() -> void: buy_item(name, int(p[0])), func() -> void: sell_item(name, int(p[1])))

func buy_item(name: String, price: int) -> void:
	if has_method("_confirmation_prompts_enabled") and bool(call("_confirmation_prompts_enabled")):
		call("_request_action_confirmation", "Confirm purchase", "Buy 1 " + name + " for " + str(price) + " coins?", Callable(self, "_buy_item_now").bind(name, price))
		return
	_buy_item_now(name, price)

func _buy_item_now(name: String, price: int) -> void:
	if coins < price:
		status_label.text = "Not enough coins."
		return
	coins -= price
	inventory[name] = int(inventory.get(name,0)) + 1
	update_coins()
	status_label.text = "Bought 1 " + name + "."

func sell_item(name: String, price: int) -> void:
	if has_method("_confirmation_prompts_enabled") and bool(call("_confirmation_prompts_enabled")):
		call("_request_action_confirmation", "Confirm sale", "Sell 1 " + name + " for " + str(price) + " coins?", Callable(self, "_sell_item_now").bind(name, price))
		return
	_sell_item_now(name, price)

func _sell_item_now(name: String, price: int) -> void:
	if int(inventory.get(name,0)) <= 0:
		status_label.text = "You do not own " + name + "."
		return
	inventory[name] = int(inventory.get(name,0)) - 1
	coins += price
	update_coins()
	status_label.text = "Sold 1 " + name + "."

func show_food() -> void:
	heading("Food")
	var l := Label.new()
	l.text = "Food currently has no hunger or gameplay effects."
	content.add_child(l)
	for food in food_prices:
		var item := str(food)
		var row := Label.new()
		row.text = item + "  Own: " + str(inventory.get(item,0))
		content.add_child(row)

func show_inventory(tab: String) -> void:
	clear_content()
	heading("Inventory")
	add_tabs(["Resources","Equipment","Statistics"], func(name: String) -> void: show_inventory(name))
	if tab == "Resources": show_inventory_resources()
	elif tab == "Equipment": show_inventory_equipment()
	else: show_statistics()

func show_inventory_resources() -> void:
	var search_row := HBoxContainer.new()
	var search := LineEdit.new()
	search.placeholder_text = "Search inventory..."
	search.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	search_row.add_child(search)
	var filter := OptionButton.new()
	var categories: Array[String] = ["All Types", "Raw Materials", "Processed Materials", "Wood", "Tools", "Equipment", "Food", "Other"]
	for category in categories:
		filter.add_item(category)
	search_row.add_child(filter)
	content.add_child(search_row)
	var item_list := VBoxContainer.new()
	item_list.name = "InventoryItemList"
	content.add_child(item_list)
	var refresh_items := func() -> void:
		for child in item_list.get_children():
			child.queue_free()
		var names: Array[String] = []
		for raw_key in inventory.keys():
			var item_name: String = str(raw_key)
			if int(inventory.get(raw_key, 0)) <= 0:
				continue
			var category: String = _inventory_category(item_name)
			var selected_category: String = categories[filter.selected]
			if selected_category != "All Types" and category != selected_category:
				continue
			if not item_name.to_lower().contains(search.text.strip_edges().to_lower()):
				continue
			names.append(item_name)
		names.sort()
		for item_name in names:
			var item_row := HBoxContainer.new()
			var label := Label.new()
			label.text = item_name + "  x" + str(inventory.get(item_name, 0))
			label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			item_row.add_child(label)
			var details := Button.new()
			details.text = "Details"
			details.pressed.connect(_show_inventory_item_details.bind(item_name))
			item_row.add_child(details)
			item_list.add_child(item_row)
	search.text_changed.connect(func(_text: String) -> void: refresh_items.call())
	filter.item_selected.connect(func(_index: int) -> void: refresh_items.call())
	refresh_items.call()

func _inventory_category(item_name: String) -> String:
	if item_name.ends_with("Pickaxe") or item_name.ends_with("Axe") or item_name.ends_with("Hammer"):
		return "Tools"
	if is_equipment(item_name):
		return "Equipment"
	if item_name in WOOD_NAMES or item_name.ends_with(" Wood"):
		return "Wood"
	if item_name.begins_with("Pure "):
		return "Processed Materials"
	if item_name.ends_with(" Ore") or item_name in RESOURCE_NAMES or item_name == "Stone":
		return "Raw Materials"
	if item_name in food_prices:
		return "Food"
	if item_name.ends_with("Pickaxe") or item_name.ends_with("Axe") or item_name.ends_with("Hammer"):
		return "Tools"
	return "Other"

func _show_inventory_item_details(item_name: String) -> void:
	var box := AcceptDialog.new()
	box.title = item_name
	box.dialog_text = "Category: " + _inventory_category(item_name) + "\nQuantity: " + str(inventory.get(item_name, 0))
	add_child(box)
	box.confirmed.connect(box.queue_free)
	box.canceled.connect(box.queue_free)
	box.popup_centered()

func is_equipment(name: String) -> bool:
	for item_type in EQUIPMENT_TYPES:
		if name.ends_with(item_type): return true
	return false

func show_inventory_equipment() -> void:
	heading("Equipped")
	for slot in equipped:
		var l := Label.new()
		l.text = slot + ": " + (str(equipped[slot]) if str(equipped[slot]) != "" else "Empty")
		content.add_child(l)
	content.add_child(HSeparator.new())
	heading("Owned Equipment")
	for key in inventory:
		var name := str(key)
		if is_equipment(name) and int(inventory[key]) > 0:
			var row := HBoxContainer.new()
			var l := Label.new()
			l.text = name + " x" + str(inventory[key])
			l.custom_minimum_size = Vector2(260,40)
			row.add_child(l)
			var b := Button.new()
			b.text = "Equip"
			b.pressed.connect(func() -> void: equip_item(name))
			row.add_child(b)
			content.add_child(row)

func equip_item(name: String) -> void:
	var slot := "Weapon"
	for item_type in EQUIPMENT_TYPES:
		if name.ends_with(item_type):
			slot = "Weapon" if item_type == "Sword" or item_type == "Mace" else item_type
			break
	equipped[slot] = name
	status_label.text = name + " equipped."
	show_inventory("Equipment")

func show_statistics() -> void:
	var coin_text := str(coins)
	if has_method("_format_setting_number"):
		coin_text = str(call("_format_setting_number", coins))
	var values := [
		"Coins: " + coin_text,
		"Current Tier: " + TIER_NAMES[unlocked_tier],
		"Resources Mined: " + str(stats["mined"]),
		"Wood Cut: " + str(stats["wood_cut"]),
		"Items Crafted: " + str(stats["crafted"]),
		"Current Activity: " + (active_action if active_action != "" else "Idle")
	]
	for text in values:
		var l := Label.new()
		l.text = text
		content.add_child(l)

func _process(delta: float) -> void:
	if active_action == "": return
	active_elapsed += delta
	var progress_value: float = min(100.0, active_elapsed / active_total * 100.0)
	if has_method("_reduce_progress_animation") and bool(call("_reduce_progress_animation")):
		progress_value = floor(progress_value / 10.0) * 10.0
	progress.value = progress_value
	if active_elapsed >= active_total: complete_operation()

func update_coins() -> void:
	if coins_label == null:
		return
	var coin_text := str(coins)
	if has_method("_format_setting_number"):
		coin_text = str(call("_format_setting_number", coins))
	coins_label.text = "Coins: " + coin_text
