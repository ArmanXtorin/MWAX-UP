extends "res://scripts/main_original.gd"

# Responsive UI wrapper. Keeps Coins visible and places all navigation buttons
# in a horizontal ScrollContainer so smaller resolutions do not crush the header.
func build_ui() -> void:
	var bg := ColorRect.new()
	bg.color = Color("#11151c")
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)

	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 12)
	margin.add_theme_constant_override("margin_right", 12)
	margin.add_theme_constant_override("margin_top", 12)
	margin.add_theme_constant_override("margin_bottom", 12)
	add_child(margin)

	var main := VBoxContainer.new()
	main.add_theme_constant_override("separation", 8)
	margin.add_child(main)

	var header := HBoxContainer.new()
	header.custom_minimum_size = Vector2(0, 44)
	main.add_child(header)

	var title := Label.new()
	title.text = "MILKY WAY"
	title.add_theme_font_size_override("font_size", 24)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(title)

	coins_label = Label.new()
	coins_label.text = "Coins: 0"
	coins_label.add_theme_font_size_override("font_size", 20)
	coins_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	coins_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	coins_label.custom_minimum_size = Vector2(150, 40)
	header.add_child(coins_label)

	var nav_scroll := ScrollContainer.new()
	nav_scroll.custom_minimum_size = Vector2(0, 50)
	nav_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	nav_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	nav_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	main.add_child(nav_scroll)

	var nav := HBoxContainer.new()
	nav.name = "MainNavigation"
	nav.add_theme_constant_override("separation", 5)
	nav_scroll.add_child(nav)

	for page in ["Mining", "Woodcutting", "Blacksmith", "Shop", "Food", "Inventory"]:
		var b := Button.new()
		b.text = page
		b.custom_minimum_size = Vector2(120, 42)
		b.pressed.connect(func() -> void: show_page(page))
		nav.add_child(b)

	main.add_child(HSeparator.new())

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	main.add_child(scroll)

	content = VBoxContainer.new()
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.add_theme_constant_override("separation", 8)
	scroll.add_child(content)

	status_label = Label.new()
	status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	main.add_child(status_label)

	progress = ProgressBar.new()
	progress.visible = false
	progress.custom_minimum_size = Vector2(0, 24)
	main.add_child(progress)

	dialog = AcceptDialog.new()
	dialog.title = "Milky Way"
	add_child(dialog)

	update_coins()

func _add_extra_navigation() -> void:
	# main.gd owns the responsive navigation, so add the feature pages here.
	var nav: HBoxContainer = null
	var margin := get_node_or_null("MarginContainer")
	if margin != null:
		var main := margin.get_child(0)
		if main is VBoxContainer and main.get_child_count() > 1:
			var nav_scroll := main.get_child(1)
			if nav_scroll is ScrollContainer and nav_scroll.get_child_count() > 0:
				var candidate := nav_scroll.get_child(0)
				if candidate is HBoxContainer:
					nav = candidate

	if nav == null:
		return

	for page in ["Quests", "Daily Rewards", "Token Store"]:
		var button := Button.new()
		button.text = page
		button.custom_minimum_size = Vector2(140, 42)
		button.pressed.connect(_extra_page_pressed.bind(page))
		nav.add_child(button)

func _extra_page_pressed(page: String) -> void:
	show_extra_page(page)
