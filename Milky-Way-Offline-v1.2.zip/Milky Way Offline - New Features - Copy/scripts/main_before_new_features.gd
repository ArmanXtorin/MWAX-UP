extends "res://scripts/main_features.gd"

# Blacksmith repair layer.
# Keeps the existing feature systems untouched and restores working
# Blacksmith item selection, recipes, crafting, and tier unlocking.

func show_blacksmith() -> void:
	clear_content()
	var safe_tier: int = clamp(unlocked_tier, 0, TIER_NAMES.size() - 1)
	heading("Blacksmith - " + TIER_NAMES[safe_tier] + " Tier")

	var info: Label = Label.new()
	info.text = "Select an item to see its recipe and crafting time."
	content.add_child(info)

	for raw_item_type in EQUIPMENT_TYPES:
		var item_type: String = str(raw_item_type)
		var button: Button = Button.new()
		button.text = TIER_NAMES[safe_tier] + " " + item_type
		button.custom_minimum_size = Vector2(260, 42)
		button.pressed.connect(_blacksmith_item_pressed.bind(safe_tier, item_type))
		content.add_child(button)

func _blacksmith_item_pressed(tier: int, item_type: String) -> void:
	var recipe: Dictionary = get_recipe(tier, item_type)
	show_recipe(recipe)

func get_recipe(tier: int, item_type: String) -> Dictionary:
	var safe_tier: int = clamp(tier, 0, TIER_NAMES.size() - 1)
	var materials: Dictionary = {}
	var amount: int = 10

	match item_type:
		"Sword", "Mace", "Shield":
			amount = 12
		"Helmet", "Knee Armor":
			amount = 8
		"Body Armor":
			amount = 16
		"Leg Armor":
			amount = 14
		_:
			amount = 10

	var wood_name: String = WOOD_NAMES[0] if safe_tier == 0 else WOOD_NAMES[safe_tier - 1]
	materials[wood_name] = amount

	if safe_tier > 0:
		var resource_name: String = str(RESOURCE_NAMES[safe_tier - 1])
		materials[resource_name] = amount

	return {
		"name": TIER_NAMES[safe_tier] + " " + item_type,
		"time": TIER_TIMES[safe_tier],
		"materials": materials
	}

func show_recipe(recipe: Dictionary) -> void:
	clear_content()
	heading(str(recipe.get("name", "Recipe")))

	var time_label: Label = Label.new()
	time_label.text = "Crafting time: " + str(recipe.get("time", 0.0)) + " seconds"
	content.add_child(time_label)

	var req_title: Label = Label.new()
	req_title.text = "REQUIRED MATERIALS (You have / Need)"
	content.add_child(req_title)

	var can_craft: bool = true
	var materials: Dictionary = recipe.get("materials", {})
	for key in materials:
		var need: int = int(materials[key])
		if need <= 0:
			continue
		var have: int = int(inventory.get(key, 0))
		var label: Label = Label.new()
		label.text = str(key) + ": " + str(have) + " / " + str(need)
		content.add_child(label)
		if have < need:
			can_craft = false

	var result: Label = Label.new()
	result.text = "RESULT: +1 " + str(recipe.get("name", "Item"))
	content.add_child(result)

	var once: Button = Button.new()
	once.text = "Craft Once"
	once.disabled = not can_craft
	once.pressed.connect(_craft_recipe_pressed.bind(recipe, "one"))
	content.add_child(once)

	var infinite: Button = Button.new()
	infinite.text = "Craft Infinite (until materials run out)"
	infinite.disabled = not can_craft
	infinite.pressed.connect(_craft_recipe_pressed.bind(recipe, "infinite"))
	content.add_child(infinite)

	var back: Button = Button.new()
	back.text = "Back"
	back.pressed.connect(show_blacksmith)
	content.add_child(back)

func _craft_recipe_pressed(recipe: Dictionary, mode: String) -> void:
	ask_craft_mode(recipe, mode)

func check_tier_unlock() -> void:
	if unlocked_tier >= TIER_NAMES.size() - 1:
		return

	var current_tier: int = unlocked_tier
	for raw_item_type in EQUIPMENT_TYPES:
		var item_type: String = str(raw_item_type)
		var item_name: String = TIER_NAMES[current_tier] + " " + item_type
		if int(inventory.get(item_name, 0)) <= 0:
			return

	unlocked_tier += 1
	status_label.text = "Tier completed! " + TIER_NAMES[unlocked_tier] + " Tier unlocked!"
	show_blacksmith()

func show_token_store() -> void:
	clear_content()
	heading("Token Store")

	var balance: Label = Label.new()
	balance.text = "Quest Tokens: " + str(quest_tokens)
	content.add_child(balance)

	var subtitle: Label = Label.new()
	subtitle.text = "Spend Quest Tokens on temporary potions."
	content.add_child(subtitle)

	for raw_potion_name in POTIONS.keys():
		var potion_name: String = str(raw_potion_name)
		var data: Dictionary = POTIONS[potion_name]

		var row: HBoxContainer = HBoxContainer.new()
		row.custom_minimum_size = Vector2(0, 44)

		var label: Label = Label.new()
		label.text = potion_name + " - " + str(data["effect"]) + " - " + str(data["cost"]) + " Tokens"
		label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(label)

		var buy: Button = Button.new()
		buy.text = "Buy"
		buy.custom_minimum_size = Vector2(100, 40)
		buy.disabled = quest_tokens < int(data["cost"])
		buy.pressed.connect(_token_store_buy_pressed.bind(potion_name))
		row.add_child(buy)

		content.add_child(row)

func _token_store_buy_pressed(potion_name: String) -> void:
	buy_potion(potion_name)
