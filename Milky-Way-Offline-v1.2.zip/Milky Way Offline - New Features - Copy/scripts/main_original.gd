extends "res://main_original.gd.backup.beta01"

const SAVE_PATH := "user://milky_way_save.json"
const POTION_DURATION := 20.0
const QUESTS := [
	{"id":"mine_5","title":"Stone Worker","description":"Mine 5 resources.","kind":"mined","goal":5},
	{"id":"wood_5","title":"Lumberjack","description":"Cut 5 wood.","kind":"wood_cut","goal":5},
	{"id":"craft_1","title":"First Craft","description":"Craft 1 equipment item.","kind":"crafted","goal":1},
	{"id":"buy_3","title":"Shopper","description":"Buy 3 items.","kind":"bought","goal":3},
	{"id":"sell_3","title":"Merchant","description":"Sell 3 items.","kind":"sold","goal":3},
	{"id":"earn_100","title":"Pocket Change","description":"Earn 100 coins from selling.","kind":"coins_earned","goal":100}
]
const DAILY_REWARDS := [5, 10, 15, 20, 25, 30, 50]
const POTIONS := {
	"Mining Potion": {"cost":5, "effect":"Mining speed +25%"},
	"Woodcutting Potion": {"cost":5, "effect":"Woodcutting speed +25%"},
	"Universal Potion": {"cost":25, "effect":"Mining + Woodcutting speed +25%"},
	"1.5x Resource Potion": {"cost":25, "effect":"50% chance for an extra resource"}
}

var quest_tokens: int = 0
var quest_progress: Dictionary = {}
var quest_completed: Dictionary = {}
var activity_history: Array[String] = []
var daily_last_claim: int = 0
var daily_day: int = 0
var active_potions: Dictionary = {}
var autosave_elapsed: float = 0.0
var shop_bought: int = 0
var shop_sold: int = 0
var coins_earned: int = 0
var selected_tier: int = 0

func _ready() -> void:
	super._ready()
	_load_save()
	_update_potion_status()
	_add_extra_navigation()
	update_coins()

func _process(delta: float) -> void:
	super._process(delta)
	autosave_elapsed += delta
	if autosave_elapsed >= 10.0:
		autosave_elapsed = 0.0
		save_game()
	_update_potion_status()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		save_game()

func _add_extra_navigation() -> void:
	var nav: HBoxContainer = null
	for child in get_children():
		if child is MarginContainer:
			var main_node = child.get_child(0)
			if main_node is VBoxContainer:
				for candidate in main_node.get_children():
					if candidate is ScrollContainer:
						var scroll_child = candidate.get_child(0)
						if scroll_child is HBoxContainer:
							nav = scroll_child
							break
					if candidate is HBoxContainer and candidate.get_child_count() > 0:
						var first = candidate.get_child(0)
						if first is Button and str(first.text) == "Mining":
							nav = candidate
							break
			if nav != null:
				break
	if nav == null:
			return
	for page in ["Quests", "Daily Rewards", "Token Store"]:
		var button := Button.new()
		button.text = page
		button.custom_minimum_size = Vector2(140, 42)
		button.pressed.connect(_extra_page_pressed.bind(page))
		nav.add_child(button)

func _extra_page_pressed(page: String) -> void:
	show_extra_page(page)

func show_extra_page(page: String) -> void:
	clear_content()
	match page:
		"Quests": show_quests()
		"Daily Rewards": show_daily_rewards()
		"Token Store": show_token_store()

func show_quests() -> void:
	heading("Quests")
	var token_label := Label.new()
	token_label.text = "Quest Tokens: " + str(quest_tokens)
	content.add_child(token_label)
	for quest in QUESTS:
		var id: String = str(quest["id"])
		var row := VBoxContainer.new()
		var title := Label.new()
		var current: int = int(quest_progress.get(id, 0))
		title.text = str(quest["title"]) + " - " + str(quest["description"])
		row.add_child(title)
		var progress_label := Label.new()
		if bool(quest_completed.get(id, false)):
			progress_label.text = "Completed - +1 Quest Token"
		else:
			progress_label.text = str(min(current, int(quest["goal"]))) + " / " + str(quest["goal"])
		row.add_child(progress_label)
		content.add_child(row)
		content.add_child(HSeparator.new())

func show_daily_rewards() -> void:
	heading("Daily Rewards")
	var info := Label.new()
	info.text = "Daily reward day: " + str(daily_day + 1) + " / 7"
	content.add_child(info)
	var reward := Label.new()
	reward.text = "Today's reward: " + str(DAILY_REWARDS[daily_day]) + " Coins"
	content.add_child(reward)
	var claim := Button.new()
	claim.text = "Claim Daily Reward"
	claim.disabled = not _can_claim_daily()
	claim.pressed.connect(_claim_daily_reward)
	content.add_child(claim)

func show_token_store() -> void:
	heading("Token Store")
	var balance := Label.new()
	balance.text = "Quest Tokens: " + str(quest_tokens)
	content.add_child(balance)
	add_tabs(["Potions"], func(_name: String) -> void: show_token_store())
	for potion_name in POTIONS:
		var data: Dictionary = POTIONS[potion_name]
		var row := HBoxContainer.new()
		var label := Label.new()
		label.text = str(potion_name) + " - " + str(data["effect"]) + " - " + str(data["cost"]) + " Tokens"
		label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(label)
		var buy := Button.new()
		buy.text = "Buy"
		buy.disabled = quest_tokens < int(data["cost"])
		buy.pressed.connect(_potion_buy_pressed.bind(str(potion_name)))
		row.add_child(buy)
		content.add_child(row)

func _potion_buy_pressed(potion_name: String) -> void:
	buy_potion(potion_name)

func buy_potion(potion_name: String) -> void:
	if not POTIONS.has(potion_name):
		return
	var cost: int = int(POTIONS[potion_name]["cost"])
	if quest_tokens < cost:
		status_label.text = "Not enough Quest Tokens."
		return
	quest_tokens -= cost
	active_potions[potion_name] = Time.get_unix_time_from_system() + POTION_DURATION
	_add_history("Activated " + potion_name + " for 20s.")
	status_label.text = potion_name + " activated for 20 seconds."
	save_game()
	show_token_store()

func _update_potion_status() -> void:
	var now: float = Time.get_unix_time_from_system()
	var expired: Array[String] = []
	for potion_name in active_potions:
		if float(active_potions[potion_name]) <= now:
			expired.append(str(potion_name))
	for potion_name in expired:
		active_potions.erase(potion_name)

func _has_potion(potion_name: String) -> bool:
	_update_potion_status()
	return active_potions.has(potion_name)

func _speed_multiplier(kind: String) -> float:
	if kind == "mining" and (_has_potion("Mining Potion") or _has_potion("Universal Potion")):
		return 0.75
	if kind == "wood" and (_has_potion("Woodcutting Potion") or _has_potion("Universal Potion")):
		return 0.75
	return 1.0

func start_action(name: String, seconds: float, mode: String, kind: String, index: int) -> void:
	super.start_action(name, seconds * _speed_multiplier(kind), mode, kind, index)

func complete_operation() -> void:
	if active_kind == "mining":
		var item: String = str(RESOURCE_NAMES[active_index])
		var amount: int = 1
		if _has_potion("1.5x Resource Potion") and randf() < 0.5:
			amount = 2
		inventory[item] = int(inventory.get(item, 0)) + amount
		stats["mined"] = int(stats.get("mined", 0)) + amount
		_update_quest("mined", amount)
		_add_history("Mined " + str(amount) + " " + item + ".")
		_complete_non_craft_operation()
		return
	if active_kind == "wood":
		var wood_name: String = str(WOOD_NAMES[active_index])
		var amount: int = 1
		if _has_potion("1.5x Resource Potion") and randf() < 0.5:
			amount = 2
		inventory[wood_name] = int(inventory.get(wood_name, 0)) + amount
		stats["wood_cut"] = int(stats.get("wood_cut", 0)) + amount
		_update_quest("wood_cut", amount)
		_add_history("Chopped " + str(amount) + " " + wood_name + ".")
		_complete_non_craft_operation()
		return
	var craft_name: String = str(active_action)
	super.complete_operation()
	if active_kind == "craft":
		_update_quest("crafted", 1)
		_add_history("Crafted " + craft_name + ".")

func _complete_non_craft_operation() -> void:
	status_label.text = active_action + " completed."
	if active_mode == "infinite":
		active_elapsed = 0.0
		active_total = TIER_TIMES[active_index] * _speed_multiplier(active_kind)
		progress.value = 0.0
	else:
		stop_action(status_label.text)

func _update_quest(kind: String, amount: int) -> void:
	for quest in QUESTS:
		if str(quest["kind"]) != kind:
			continue
		var id: String = str(quest["id"])
		if bool(quest_completed.get(id, false)):
			continue
		var current: int = int(quest_progress.get(id, 0)) + amount
		quest_progress[id] = current
		if current >= int(quest["goal"]):
			quest_completed[id] = true
			quest_tokens += 1
			_add_history("Quest completed: " + str(quest["title"]) + " (+1 Quest Token).")
			status_label.text = "Quest completed! +1 Quest Token."

func _can_claim_daily() -> bool:
	if daily_last_claim == 0:
		return true
	return Time.get_unix_time_from_system() - daily_last_claim >= 86400

func _claim_daily_reward() -> void:
	if not _can_claim_daily():
		status_label.text = "Daily reward already claimed."
		return
	var reward: int = int(DAILY_REWARDS[daily_day])
	coins += reward
	update_coins()
	daily_last_claim = int(Time.get_unix_time_from_system())
	daily_day = (daily_day + 1) % DAILY_REWARDS.size()
	_add_history("Claimed daily reward: +" + str(reward) + " coins.")
	status_label.text = "Daily reward claimed: +" + str(reward) + " coins."
	save_game()
	show_daily_rewards()

func buy_item(name: String, price: int) -> void:
	var before: int = coins
	super.buy_item(name, price)
	if coins != before:
		shop_bought += 1
		_update_quest("bought", 1)
		_add_history("Bought 1 " + name + ".")
		save_game()

func sell_item(name: String, price: int) -> void:
	var before: int = coins
	super.sell_item(name, price)
	if coins > before:
		var earned: int = coins - before
		shop_sold += 1
		coins_earned += earned
		_update_quest("sold", 1)
		_update_quest("coins_earned", earned)
		_add_history("Sold 1 " + name + " for " + str(price) + " coins.")
		save_game()

func _add_history(message: String) -> void:
	activity_history.push_front(message)
	if activity_history.size() > 30:
		activity_history.resize(30)

func show_activity_history() -> void:
	clear_content()
	heading("Activity History")
	if activity_history.is_empty():
		var empty := Label.new()
		empty.text = "No activity yet."
		content.add_child(empty)
	else:
		for entry in activity_history:
			var label := Label.new()
			label.text = str(entry)
			content.add_child(label)

func show_item_details(name: String) -> void:
	clear_content()
	heading(str(name))
	var owned := Label.new()
	owned.text = "Owned: " + str(inventory.get(name, 0))
	content.add_child(owned)
	var type_label := Label.new()
	type_label.text = "Equipment" if is_equipment(name) else "Item"
	content.add_child(type_label)
	var back := Button.new()
	back.text = "Back"
	back.pressed.connect(func() -> void: show_inventory("Resources"))
	content.add_child(back)

func show_statistics() -> void:
	super.show_statistics()
	var history_button := Button.new()
	history_button.text = "Activity History"
	history_button.pressed.connect(show_activity_history)
	content.add_child(history_button)

func show_inventory(tab: String) -> void:
	super.show_inventory(tab)
	if tab != "Resources" and tab != "Equipment":
		return
	var items: Array[String] = []
	for key in inventory:
		if int(inventory[key]) > 0:
			items.append(str(key))
	for item_name in items:
		var details := Button.new()
		details.text = "Details: " + item_name
		details.pressed.connect(_inventory_details_pressed.bind(item_name))
		content.add_child(details)

func _inventory_details_pressed(item_name: String) -> void:
	show_item_details(item_name)

func get_recipe(tier: int, item_type: String) -> Dictionary:
	var safe_tier: int = clamp(tier, 0, TIER_NAMES.size() - 1)
	var materials: Dictionary = {}
	var amount: int = 10
	match item_type:
		"Sword", "Mace", "Shield":
			amount = 12
		"Helmet", "Knee Armor":
			amount = 8
		"Body Armor":
			amount = 16
		"Leg Armor":
			amount = 14
	var wood_name: String
	if safe_tier == 0:
		wood_name = str(WOOD_NAMES[0])
	else:
		wood_name = str(WOOD_NAMES[safe_tier - 1])
	materials[wood_name] = amount
	if safe_tier > 0:
		var resource_name: String = str(RESOURCE_NAMES[safe_tier - 1])
		materials[resource_name] = amount
	return {
		"name": str(TIER_NAMES[safe_tier]) + " " + item_type,
		"time": TIER_TIMES[safe_tier],
		"materials": materials
	}

func check_tier_unlock() -> void:
	if unlocked_tier >= TIER_NAMES.size() - 1:
		return
	for item_type in EQUIPMENT_TYPES:
		var item_name: String = str(TIER_NAMES[unlocked_tier]) + " " + str(item_type)
		if int(inventory.get(item_name, 0)) <= 0:
			return
	unlocked_tier += 1
	selected_tier = unlocked_tier
	status_label.text = "Tier completed! " + str(TIER_NAMES[unlocked_tier]) + " Tier unlocked!"

func save_game() -> void:
	var data := {
		"coins": coins,
		"unlocked_tier": unlocked_tier,
		"inventory": inventory,
		"crafted_equipment": crafted_equipment,
		"equipped": equipped,
		"stats": stats,
		"quest_tokens": quest_tokens,
		"quest_progress": quest_progress,
		"quest_completed": quest_completed,
		"activity_history": activity_history,
		"daily_last_claim": daily_last_claim,
		"daily_day": daily_day,
		"active_potions": active_potions,
		"shop_bought": shop_bought,
		"shop_sold": shop_sold,
		"coins_earned": coins_earned
	}
	var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify(data))
		file.close()

func _load_save() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if file == null:
		return
	var parsed = JSON.parse_string(file.get_as_text())
	file.close()
	if not parsed is Dictionary:
		return

	coins = int(parsed.get("coins", coins))
	unlocked_tier = int(parsed.get("unlocked_tier", unlocked_tier))

	var loaded_inventory = parsed.get("inventory", {})
	if loaded_inventory is Dictionary:
		inventory = loaded_inventory

	var loaded_crafted = parsed.get("crafted_equipment", {})
	if loaded_crafted is Dictionary:
		crafted_equipment = loaded_crafted

	var loaded_equipped = parsed.get("equipped", {})
	if loaded_equipped is Dictionary:
		equipped = loaded_equipped

	var loaded_stats = parsed.get("stats", {})
	if loaded_stats is Dictionary:
		stats = loaded_stats

	quest_tokens = int(parsed.get("quest_tokens", 0))
	quest_progress = parsed.get("quest_progress", {})
	quest_completed = parsed.get("quest_completed", {})

	var loaded_history = parsed.get("activity_history", [])
	if loaded_history is Array:
		activity_history.clear()
		for entry in loaded_history:
			activity_history.append(str(entry))

	daily_last_claim = int(parsed.get("daily_last_claim", 0))
	daily_day = int(parsed.get("daily_day", 0)) % DAILY_REWARDS.size()
	active_potions = parsed.get("active_potions", {})
	shop_bought = int(parsed.get("shop_bought", 0))
	shop_sold = int(parsed.get("shop_sold", 0))
	coins_earned = int(parsed.get("coins_earned", 0))
