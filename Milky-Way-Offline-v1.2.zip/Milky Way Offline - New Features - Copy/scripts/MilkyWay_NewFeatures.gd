extends "res://scripts/main.gd"

# Milky Way: Offline - New progression layer
# Equipment UI + skills + smelting + pure materials + expanded shop.
# Tier-unlock gating is intentionally removed. Tool progression is per-tool.

const SKILL_REQUIREMENTS := {
    "Wooden": 5,
    "Stone": 15,
    "Copper": 25,
    "Iron": 30,
    "Golden": 50,
    "Diamond": 75
}

const TOOL_TYPES := ["Pickaxe", "Axe", "Hammer"]

const TOOL_SKILLS := {
    "Pickaxe": "Mining",
    "Axe": "Woodcutting",
    "Hammer": "Blacksmithing"
}

const PURE_MATERIALS := {
    "Pure Stone": {"source":"Stone", "time":4.0},
    "Pure Copper": {"source":"Copper", "time":6.0},
    "Pure Iron": {"source":"Iron", "time":8.0},
    "Pure Gold": {"source":"Gold", "time":10.0},
    "Pure Diamond": {"source":"Diamond", "time":15.0}
}

const TOOL_MATERIALS := {
    "Wooden": "Oak Wood",
    "Stone": "Pure Stone",
    "Copper": "Pure Copper",
    "Iron": "Pure Iron",
    "Golden": "Pure Gold",
    "Diamond": "Pure Diamond"
}

const SMELT_YIELDS := {
    "Stone": "Pure Stone",
    "Copper": "Pure Copper",
    "Iron": "Pure Iron",
    "Gold": "Pure Gold",
    "Diamond": "Pure Diamond"
}

var skill_levels: Dictionary = {
    "Mining": 1,
    "Woodcutting": 1,
    "Blacksmithing": 1
}

var tool_progression: Dictionary = {
    "Pickaxe": 0,
    "Axe": 0,
    "Hammer": 0
}

var smelting_queue: Dictionary = {}
var pure_materials: Dictionary = {}
var selected_equipment_tab := "Tools"

func _ready() -> void:
    super._ready()
    for material in PURE_MATERIALS:
        pure_materials[material] = 0
        inventory[material] = int(inventory.get(material, 0))
    _load_new_progression()
    _refresh_equipment_state()

func _process(delta: float) -> void:
    super._process(delta)
    _tick_smelting(delta)

func _refresh_equipment_state() -> void:
    for tool in TOOL_TYPES:
        if not tool_progression.has(tool):
            tool_progression[tool] = 0

func _tier_name(tier: int) -> String:
    return TIER_NAMES[clamp(tier, 0, TIER_NAMES.size() - 1)]

func _skill_for_tool(tool: String) -> String:
    return str(TOOL_SKILLS.get(tool, "Blacksmithing"))

func _tool_can_upgrade(tool: String) -> bool:
    var current := int(tool_progression.get(tool, 0))
    if current >= TIER_NAMES.size() - 1:
        return false
    var next := current + 1
    var tier_name := _tier_name(next)
    return int(skill_levels.get(_skill_for_tool(tool), 1)) >= int(SKILL_REQUIREMENTS[tier_name])

func _tool_recipe(tool: String, tier: int) -> Dictionary:
    var tier_name := _tier_name(tier)
    var materials: Dictionary = {}
    materials[TOOL_MATERIALS[tier_name]] = 1
    if tier > 0:
        materials[_tier_name(tier - 1) + " " + tool] = 1
    return {
        "name": tier_name + " " + tool,
        "materials": materials,
        "skill": _skill_for_tool(tool),
        "level": int(SKILL_REQUIREMENTS[tier_name])
    }

func show_blacksmith() -> void:
    clear_content()
    heading("Blacksmith")

    var info := Label.new()
    info.text = "Craft equipment. Higher tiers require the previous tool, which is consumed."
    content.add_child(info)

    add_tabs(["Tools", "Armor", "Weapons"], func(name: String) -> void:
        selected_equipment_tab = name
        show_blacksmith()
    )

    if selected_equipment_tab == "Tools":
        _show_tool_progression()
    else:
        _show_equipment_catalog(selected_equipment_tab)

func _show_tool_progression() -> void:
    for tool in TOOL_TYPES:
        var current := int(tool_progression.get(tool, 0))
        var row := VBoxContainer.new()

        var title := Label.new()
        title.text = tool + " - " + _tier_name(current)
        row.add_child(title)

        var skill := _skill_for_tool(tool)
        var level := int(skill_levels.get(skill, 1))
        var next_text := "MAX"
        if current < TIER_NAMES.size() - 1:
            var next_tier := _tier_name(current + 1)
            next_text = next_tier + " requires " + skill + " Lv. " + str(SKILL_REQUIREMENTS[next_tier])
        var details := Label.new()
        details.text = skill + " Lv. " + str(level) + " | " + next_text
        row.add_child(details)

        if current < TIER_NAMES.size() - 1:
            var recipe := _tool_recipe(tool, current + 1)
            var button := Button.new()
            button.text = "Craft " + str(recipe["name"])
            button.disabled = not _can_craft_recipe(recipe)
            button.pressed.connect(_craft_tool_pressed.bind(tool, current + 1))
            row.add_child(button)

        content.add_child(row)
        content.add_child(HSeparator.new())

func _craft_tool_pressed(tool: String, tier: int) -> void:
    if not _tool_can_upgrade(tool):
        status_label.text = "Skill level too low for this tool tier."
        return
    var recipe := _tool_recipe(tool, tier)
    if not _can_craft_recipe(recipe):
        status_label.text = "Missing materials for " + str(recipe["name"]) + "."
        return
    _consume_materials(recipe["materials"])
    tool_progression[tool] = tier
    var item_name := str(recipe["name"])
    inventory[item_name] = int(inventory.get(item_name, 0)) + 1
    crafted_equipment[item_name] = true
    stats["crafted"] = int(stats.get("crafted", 0)) + 1
    skill_levels[recipe["skill"]] = int(skill_levels.get(recipe["skill"], 1)) + 1
    status_label.text = item_name + " crafted. " + recipe["skill"] + " XP gained."
    save_game()
    show_blacksmith()

func _show_equipment_catalog(category: String) -> void:
    var types: Array[String] = []
    if category == "Armor":
        types = ["Helmet", "Body Armor", "Leg Armor", "Knee Armor", "Shield"]
    else:
        types = ["Sword", "Mace"]

    for tier in range(TIER_NAMES.size()):
        for item_type in types:
            var name := _tier_name(tier) + " " + item_type
            var label := Label.new()
            label.text = name + " | Materials use pure " + _tier_name(tier) + " resources."
            content.add_child(label)

func _can_craft_recipe(recipe: Dictionary) -> bool:
    for material in recipe["materials"]:
        if int(inventory.get(material, 0)) < int(recipe["materials"][material]):
            return false
    return true

func _consume_materials(materials: Dictionary) -> void:
    for material in materials:
        inventory[material] = int(inventory.get(material, 0)) - int(materials[material])

func show_smelting() -> void:
    clear_content()
    heading("Smelting")
    var info := Label.new()
    info.text = "Convert mined ore into pure materials used by higher-tier equipment."
    content.add_child(info)

    for ore in SMELT_YIELDS:
        var pure := str(SMELT_YIELDS[ore])
        var row := HBoxContainer.new()
        var label := Label.new()
        label.text = ore + "  ->  " + pure + "   Own: " + str(inventory.get(ore, 0))
        label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        row.add_child(label)

        var button := Button.new()
        button.text = "Smelt 1"
        button.disabled = int(inventory.get(ore, 0)) <= 0
        button.pressed.connect(_smelt_pressed.bind(ore))
        row.add_child(button)
        content.add_child(row)

func _smelt_pressed(ore: String) -> void:
    if int(inventory.get(ore, 0)) <= 0:
        return
    inventory[ore] = int(inventory.get(ore, 0)) - 1
    var pure := str(SMELT_YIELDS[ore])
    inventory[pure] = int(inventory.get(pure, 0)) + 1
    pure_materials[pure] = int(pure_materials.get(pure, 0)) + 1
    skill_levels["Blacksmithing"] = int(skill_levels.get("Blacksmithing", 1)) + 1
    status_label.text = "Smelted 1 " + ore + " into " + pure + "."
    save_game()
    show_smelting()

func _tick_smelting(_delta: float) -> void:
    # Reserved for timed batch smelting. Single-smelt is instant for now.
    pass

func show_inventory(tab: String) -> void:
    if tab == "Equipment":
        clear_content()
        heading("Equipment")
        _show_equipment_inventory()
        return
    super.show_inventory(tab)

func _show_equipment_inventory() -> void:
    for tool in TOOL_TYPES:
        var tier := int(tool_progression.get(tool, 0))
        var name := _tier_name(tier) + " " + tool
        var row := HBoxContainer.new()
        var label := Label.new()
        label.text = tool + ": " + name
        label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        row.add_child(label)
        var equip := Button.new()
        equip.text = "Equip"
        equip.pressed.connect(_equip_new_tool.bind(tool, name))
        row.add_child(equip)
        content.add_child(row)

func _equip_new_tool(tool: String, name: String) -> void:
    equipped[tool] = name
    status_label.text = name + " equipped."
    save_game()

func show_shop(tab: String) -> void:
    clear_content()
    heading("Shop")
    add_tabs(["Resources", "Pure Materials", "Equipment", "Food"], func(name: String) -> void: show_shop(name))

    match tab:
        "Resources":
            show_shop_resources()
        "Pure Materials":
            _show_pure_material_shop()
        "Equipment":
            _show_expanded_equipment_shop()
        _:
            show_shop_food()

func _show_pure_material_shop() -> void:
    var prices := {"Pure Stone":15, "Pure Copper":30, "Pure Iron":70, "Pure Gold":150, "Pure Diamond":500}
    for material in prices:
        var price := int(prices[material])
        shop_row(str(material), price, int(price / 2),
            func() -> void: buy_item(str(material), price),
            func() -> void: sell_item(str(material), int(price / 2)))

func _show_expanded_equipment_shop() -> void:
    for tier in range(TIER_NAMES.size()):
        for tool in TOOL_TYPES:
            var name := _tier_name(tier) + " " + tool
            var price := 100 * (tier + 1) * (tier + 1)
            shop_row(name, price, int(price / 2),
                func() -> void: buy_item(name, price),
                func() -> void: sell_item(name, int(price / 2)))

func save_game() -> void:
    super.save_game()
    var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
    var data: Dictionary = {}
    if file:
        var parsed = JSON.parse_string(file.get_as_text())
        file.close()
        if parsed is Dictionary:
            data = parsed
    data["skill_levels"] = skill_levels
    data["tool_progression"] = tool_progression
    data["pure_materials"] = pure_materials
    file = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if file:
        file.store_string(JSON.stringify(data))
        file.close()

func _load_new_progression() -> void:
    if not FileAccess.file_exists(SAVE_PATH):
        return
    var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
    if file == null:
        return
    var parsed = JSON.parse_string(file.get_as_text())
    file.close()
    if not parsed is Dictionary:
        return
    var loaded_skills = parsed.get("skill_levels", {})
    if loaded_skills is Dictionary:
        for key in loaded_skills:
            skill_levels[str(key)] = int(loaded_skills[key])
    var loaded_tools = parsed.get("tool_progression", {})
    if loaded_tools is Dictionary:
        for key in loaded_tools:
            tool_progression[str(key)] = int(loaded_tools[key])
    var loaded_pure = parsed.get("pure_materials", {})
    if loaded_pure is Dictionary:
        for key in loaded_pure:
            pure_materials[str(key)] = int(loaded_pure[key])
            inventory[str(key)] = int(loaded_pure[key])

# The old global tier-unlock system is deliberately bypassed.
func check_tier_unlock() -> void:
    pass

# Mining/Woodcutting remain available at all tiers. Skill requirements govern tools.
func show_mining() -> void:
    super.show_mining()

func show_woodcutting() -> void:
    super.show_woodcutting()
