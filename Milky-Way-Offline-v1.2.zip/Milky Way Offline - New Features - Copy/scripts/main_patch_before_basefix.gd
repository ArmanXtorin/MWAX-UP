extends "res://scripts/main_original.gd"

# UI patch layer: keep the original game systems intact while fixing
# Blacksmith navigation and the extra feature tabs.

func _add_extra_navigation() -> void:
	var nav: HBoxContainer = null
	for child in get_children():
		if child is MarginContainer:
			var main_node: Node = child.get_child(0) if child.get_child_count() > 0 else null
			if main_node is VBoxContainer:
				for candidate in main_node.get_children():
					if candidate is HBoxContainer:
						var first: Node = candidate.get_child(0) if candidate.get_child_count() > 0 else null
						if first is Button and str(first.text) == "Mining":
							nav = candidate
							break
					if candidate is ScrollContainer and candidate.get_child_count() > 0:
						var scroll_child: Node = candidate.get_child(0)
						if scroll_child is HBoxContainer:
							nav = scroll_child
							break
			if nav != null:
				break

	if nav == null:
		return

	for page in ["Quests", "Daily Rewards", "Token Store"]:
		var already_exists: bool = false
		for child in nav.get_children():
			if child is Button and str(child.text) == page:
				already_exists = true
				break
		if already_exists:
			continue

		var button: Button = Button.new()
		button.text = page
		button.custom_minimum_size = Vector2(140, 42)
		button.pressed.connect(_extra_page_pressed.bind(page))
		nav.add_child(button)

func _extra_page_pressed(page: String) -> void:
	show_extra_page(page)

func show_blacksmith() -> void:
	clear_content()
	heading("Blacksmith - " + str(TIER_NAMES[unlocked_tier]) + " Tier")

	var info: Label = Label.new()
	info.text = "Select an item to see crafting time, required materials, and your current materials."
	content.add_child(info)

	for item_type in EQUIPMENT_TYPES:
		var item_type_name: String = str(item_type)
		var button: Button = Button.new()
		button.text = str(TIER_NAMES[unlocked_tier]) + " " + item_type_name
		button.custom_minimum_size = Vector2(260, 42)
		button.pressed.connect(_blacksmith_item_pressed.bind(item_type_name))
		content.add_child(button)

	add_cancel_button()

func _blacksmith_item_pressed(item_type: String) -> void:
	var recipe: Dictionary = get_recipe(unlocked_tier, item_type)
	show_recipe(recipe)
