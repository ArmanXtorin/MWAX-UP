extends "res://scripts/main_base.gd"

# Milky Way feature layer.
# Keeps the stable gameplay base in main_base.gd and adds quests,
# daily rewards, token potions, activity history, counters, and save/load.

const SAVE_PATH := "user://milky_way_save.json"
const POTION_DURATION := 20.0
const QUESTS := [
	{"id":"mine_5","title":"Stone Worker","description":"Mine 5 resources.","kind":"mined","goal":5},
	{"id":"wood_5","title":"Lumberjack","description":"Cut 5 wood.","kind":"wood_cut","goal":5},
	{"id":"craft_1","title":"First Craft","description":"Craft 1 equipment item.","kind":"crafted","goal":1},
	{"id":"buy_3","title":"Shopper","description":"Buy 3 items.","kind":"bought","goal":3},
	{"id":"sell_3","title":"Merchant","description":"Sell 3 items.","kind":"sold","goal":3},
	{"id":"earn_100","title":"Pocket Change","description":"Earn 100 coins from selling.","kind":"coins_earned","goal":100}
]
const DAILY_REWARDS := [5, 10, 15, 20, 25, 30, 50]
const POTIONS := {
	"Mining Potion": {"cost":5, "effect":"Mining speed +25%"},
	"Woodcutting Potion": {"cost":5, "effect":"Woodcutting speed +25%"},
	"Universal Potion": {"cost":25, "effect":"Mining + Woodcutting speed +25%"},
	"1.5x Resource Potion": {"cost":25, "effect":"50% chance for an extra resource"}
}

var quest_tokens: int = 0
var quest_progress: Dictionary = {}
var quest_completed: Dictionary = {}
var activity_history: Array[String] = []
var daily_last_claim: int = 0
var daily_day: int = 0
var active_potions: Dictionary = {}
var autosave_elapsed: float = 0.0
var shop_bought: int = 0
var shop_sold: int = 0
var coins_earned: int = 0

const SETTINGS_PATH := "user://milky_way_settings.json"
var game_settings: Dictionary = {
	"ui_scale": 1.0,
	"fullscreen": false,
	"resolution": "1280x720",
	"master_volume": 100.0,
	"music_volume": 100.0,
	"sfx_volume": 100.0,
	"compact_numbers": false,
	"confirmation_prompts": true,
	"fps_cap": 60,
	"reduce_animations": false
}
var _settings_controls: Dictionary = {}
var _settings_file_dialog: FileDialog
var _ui_original_min_sizes: Dictionary = {}
var _ui_original_font_sizes: Dictionary = {}
var _ui_base_theme: Theme
var _ui_base_font_size: int = 16

func _ready() -> void:
	super._ready()
	_load_save()
	_load_game_settings()
	_apply_ui_scale()
	_apply_display_settings()
	_apply_fps_setting()
	_update_potion_status()
	_add_extra_navigation()
	update_coins()

func _process(delta: float) -> void:
	super._process(delta)
	autosave_elapsed += delta
	if autosave_elapsed >= 10.0:
		autosave_elapsed = 0.0
		save_game()
	_update_potion_status()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		save_game()

func _add_extra_navigation() -> void:
	var nav: HBoxContainer = null
	for child in get_children():
		if child is MarginContainer:
			var main_node: Node = child.get_child(0) if child.get_child_count() > 0 else null
			if main_node is VBoxContainer:
				for candidate in main_node.get_children():
					if candidate is HBoxContainer and candidate.get_child_count() > 0:
						var first: Node = candidate.get_child(0)
						if first is Button and str(first.text) == "Mining":
							nav = candidate
							break
					if candidate is ScrollContainer and candidate.get_child_count() > 0:
						var scroll_child: Node = candidate.get_child(0)
						if scroll_child is HBoxContainer:
							nav = scroll_child
							break
			if nav != null:
				break
		if nav != null:
			break
	if nav == null:
		return
	for page in ["Quests", "Daily Rewards", "Token Store"]:
		var already_exists: bool = false
		for child in nav.get_children():
			if child is Button and str(child.text) == page:
				already_exists = true
				break
		if already_exists:
			continue
		var button: Button = Button.new()
		button.text = page
		button.custom_minimum_size = Vector2(140, 42)
		button.pressed.connect(_extra_page_pressed.bind(page))
		nav.add_child(button)

func _extra_page_pressed(page: String) -> void:
	show_extra_page(page)

func show_extra_page(page: String) -> void:
	clear_content()
	match page:
		"Quests": show_quests()
		"Daily Rewards": show_daily_rewards()
		"Token Store": show_token_store()
		"Settings": show_settings()

func show_quests() -> void:
	heading("Quests")
	var token_label: Label = Label.new()
	token_label.text = "Quest Tokens: " + str(quest_tokens)
	content.add_child(token_label)
	for quest in QUESTS:
		var id: String = str(quest["id"])
		var row: VBoxContainer = VBoxContainer.new()
		var title: Label = Label.new()
		var current: int = int(quest_progress.get(id, 0))
		title.text = str(quest["title"]) + " - " + str(quest["description"])
		row.add_child(title)
		var progress_label: Label = Label.new()
		if bool(quest_completed.get(id, false)):
			progress_label.text = "Completed - +1 Quest Token"
		else:
			progress_label.text = str(min(current, int(quest["goal"]))) + " / " + str(quest["goal"])
		row.add_child(progress_label)
		content.add_child(row)
		content.add_child(HSeparator.new())

func show_daily_rewards() -> void:
	heading("Daily Rewards")
	var info: Label = Label.new()
	info.text = "Daily reward day: " + str(daily_day + 1) + " / 7"
	content.add_child(info)
	var reward: Label = Label.new()
	reward.text = "Today's reward: " + str(DAILY_REWARDS[daily_day]) + " Coins"
	content.add_child(reward)
	var claim: Button = Button.new()
	claim.text = "Claim Daily Reward"
	claim.disabled = not _can_claim_daily()
	claim.pressed.connect(_claim_daily_reward)
	content.add_child(claim)

func show_token_store() -> void:
	heading("Token Store")
	var balance: Label = Label.new()
	balance.text = "Quest Tokens: " + str(quest_tokens)
	content.add_child(balance)
	add_tabs(["Potions"], func(_name: String) -> void: show_token_store())
	for potion_name in POTIONS:
		var data: Dictionary = POTIONS[potion_name]
		var row: HBoxContainer = HBoxContainer.new()
		var label: Label = Label.new()
		label.text = str(potion_name) + " - " + str(data["effect"]) + " - " + str(data["cost"]) + " Tokens"
		label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(label)
		var buy: Button = Button.new()
		buy.text = "Buy"
		buy.disabled = quest_tokens < int(data["cost"])
		buy.pressed.connect(_potion_buy_pressed.bind(str(potion_name)))
		row.add_child(buy)
		content.add_child(row)

func _potion_buy_pressed(potion_name: String) -> void:
	buy_potion(potion_name)

func buy_potion(potion_name: String) -> void:
	if not POTIONS.has(potion_name):
		return
	var cost: int = int(POTIONS[potion_name]["cost"])
	if quest_tokens < cost:
		status_label.text = "Not enough Quest Tokens."
		return
	quest_tokens -= cost
	active_potions[potion_name] = Time.get_unix_time_from_system() + POTION_DURATION
	_add_history("Activated " + potion_name + " for 20s.")
	status_label.text = potion_name + " activated for 20 seconds."
	save_game()
	show_token_store()

func _update_potion_status() -> void:
	var now: float = Time.get_unix_time_from_system()
	var expired: Array[String] = []
	for potion_name in active_potions:
		if float(active_potions[potion_name]) <= now:
			expired.append(str(potion_name))
	for potion_name in expired:
		active_potions.erase(potion_name)

func _has_potion(potion_name: String) -> bool:
	_update_potion_status()
	return active_potions.has(potion_name)

func _speed_multiplier(kind: String) -> float:
	if kind == "mining" and (_has_potion("Mining Potion") or _has_potion("Universal Potion")):
		return 0.75
	if kind == "wood" and (_has_potion("Woodcutting Potion") or _has_potion("Universal Potion")):
		return 0.75
	return 1.0

func start_action(name: String, seconds: float, mode: String, kind: String, index: int) -> void:
	super.start_action(name, seconds * _speed_multiplier(kind), mode, kind, index)

func complete_operation() -> void:
	if active_kind == "mining":
		var item: String = str(RESOURCE_NAMES[active_index])
		var amount: int = 1
		if _has_potion("1.5x Resource Potion") and randf() < 0.5:
			amount = 2
		inventory[item] = int(inventory.get(item, 0)) + amount
		stats["mined"] = int(stats.get("mined", 0)) + amount
		if has_method("_gain_new_skill"): call("_gain_new_skill", "Mining", amount)
		_update_quest("mined", amount)
		_add_history("Mined " + str(amount) + " " + item + ".")
		_complete_non_craft_operation()
		return
	if active_kind == "wood":
		var wood_name: String = str(WOOD_NAMES[active_index])
		var amount: int = 1
		if _has_potion("1.5x Resource Potion") and randf() < 0.5:
			amount = 2
		inventory[wood_name] = int(inventory.get(wood_name, 0)) + amount
		stats["wood_cut"] = int(stats.get("wood_cut", 0)) + amount
		if has_method("_gain_new_skill"): call("_gain_new_skill", "Woodcutting", amount)
		_update_quest("wood_cut", amount)
		_add_history("Chopped " + str(amount) + " " + wood_name + ".")
		_complete_non_craft_operation()
		return
	var was_craft: bool = active_kind == "craft"
	var craft_name: String = active_action
	super.complete_operation()
	if was_craft:
		_update_quest("crafted", 1)
		_add_history("Crafted " + craft_name + ".")

func _complete_non_craft_operation() -> void:
	status_label.text = active_action + " completed."
	if active_mode == "infinite":
		active_elapsed = 0.0
		active_total = TIER_TIMES[active_index] * _speed_multiplier(active_kind)
		progress.value = 0.0
	else:
		stop_action(status_label.text)

func buy_item(name: String, price: int) -> void:
	var before: int = coins
	super.buy_item(name, price)
	if coins != before:
		shop_bought += 1
		_update_quest("bought", 1)
		_add_history("Bought 1 " + name + ".")
		save_game()

func sell_item(name: String, price: int) -> void:
	var before: int = coins
	super.sell_item(name, price)
	if coins > before:
		var earned: int = coins - before
		shop_sold += 1
		coins_earned += earned
		_update_quest("sold", 1)
		_update_quest("coins_earned", earned)
		_add_history("Sold 1 " + name + " for " + str(price) + " coins.")
		save_game()

func _add_history(message: String) -> void:
	activity_history.push_front(message)
	if activity_history.size() > 30:
		activity_history.resize(30)

func show_activity_history() -> void:
	clear_content()
	heading("Activity History")
	if activity_history.is_empty():
		var empty: Label = Label.new()
		empty.text = "No activity yet."
		content.add_child(empty)
	else:
		for entry in activity_history:
			var label: Label = Label.new()
			label.text = str(entry)
			content.add_child(label)

func _update_quest(kind: String, amount: int) -> void:
	for quest in QUESTS:
		if str(quest["kind"]) != kind:
			continue
		var id: String = str(quest["id"])
		if bool(quest_completed.get(id, false)):
			continue
		var current: int = int(quest_progress.get(id, 0)) + amount
		quest_progress[id] = current
		if current >= int(quest["goal"]):
			quest_completed[id] = true
			quest_tokens += 1
			_add_history("Quest completed: " + str(quest["title"]) + " (+1 Quest Token).")
			status_label.text = "Quest completed! +1 Quest Token."

func _can_claim_daily() -> bool:
	if daily_last_claim == 0:
		return true
	return Time.get_unix_time_from_system() - daily_last_claim >= 86400

func _claim_daily_reward() -> void:
	if not _can_claim_daily():
		status_label.text = "Daily reward already claimed."
		return
	var reward: int = int(DAILY_REWARDS[daily_day])
	coins += reward
	update_coins()
	daily_last_claim = int(Time.get_unix_time_from_system())
	daily_day = (daily_day + 1) % DAILY_REWARDS.size()
	_add_history("Claimed daily reward: +" + str(reward) + " coins.")
	status_label.text = "Daily reward claimed: +" + str(reward) + " coins."
	save_game()
	show_daily_rewards()

func save_game() -> void:
	var data := {
		"coins": coins,
		"unlocked_tier": unlocked_tier,
		"inventory": inventory,
		"crafted_equipment": crafted_equipment,
		"equipped": equipped,
		"stats": stats,
		"quest_tokens": quest_tokens,
		"quest_progress": quest_progress,
		"quest_completed": quest_completed,
		"activity_history": activity_history,
		"daily_last_claim": daily_last_claim,
		"daily_day": daily_day,
		"active_potions": active_potions,
		"shop_bought": shop_bought,
		"shop_sold": shop_sold,
		"coins_earned": coins_earned
	}
	var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify(data))
		file.close()

func _load_save() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if file == null:
		return
	var parsed = JSON.parse_string(file.get_as_text())
	file.close()
	if not parsed is Dictionary:
		return

	coins = int(parsed.get("coins", coins))
	unlocked_tier = int(parsed.get("unlocked_tier", unlocked_tier))

	var loaded_inventory = parsed.get("inventory", {})
	if loaded_inventory is Dictionary:
		inventory = loaded_inventory
	var loaded_crafted = parsed.get("crafted_equipment", {})
	if loaded_crafted is Dictionary:
		crafted_equipment = loaded_crafted
	var loaded_equipped = parsed.get("equipped", {})
	if loaded_equipped is Dictionary:
		equipped = loaded_equipped
	var loaded_stats = parsed.get("stats", {})
	if loaded_stats is Dictionary:
		stats = loaded_stats

	quest_tokens = int(parsed.get("quest_tokens", 0))
	var loaded_quest_progress = parsed.get("quest_progress", {})
	if loaded_quest_progress is Dictionary:
		quest_progress = loaded_quest_progress
	var loaded_quest_completed = parsed.get("quest_completed", {})
	if loaded_quest_completed is Dictionary:
		quest_completed = loaded_quest_completed

	var loaded_history = parsed.get("activity_history", [])
	if loaded_history is Array:
		activity_history.clear()
		for entry in loaded_history:
			activity_history.append(str(entry))

	daily_last_claim = int(parsed.get("daily_last_claim", daily_last_claim))
	daily_day = int(parsed.get("daily_day", daily_day)) % DAILY_REWARDS.size()
	var loaded_potions = parsed.get("active_potions", {})
	if loaded_potions is Dictionary:
		active_potions = loaded_potions
	shop_bought = int(parsed.get("shop_bought", shop_bought))
	shop_sold = int(parsed.get("shop_sold", shop_sold))
	coins_earned = int(parsed.get("coins_earned", coins_earned))

func show_inventory(tab: String) -> void:
	super.show_inventory(tab)
	if tab != "Resources" and tab != "Equipment":
		return
	var items: Array[String] = []
	for key in inventory:
		if int(inventory[key]) > 0:
			items.append(str(key))
	for item_name in items:
		var details: Button = Button.new()
		details.text = "Details: " + item_name
		details.pressed.connect(_inventory_details_pressed.bind(item_name))
		content.add_child(details)

func _inventory_details_pressed(item_name: String) -> void:
	show_item_details(item_name)

func show_item_details(name: String) -> void:
	clear_content()
	heading(str(name))
	var owned: Label = Label.new()
	owned.text = "Owned: " + str(inventory.get(name, 0))
	content.add_child(owned)
	var type_label: Label = Label.new()
	type_label.text = "Equipment" if is_equipment(name) else "Item"
	content.add_child(type_label)
	var back: Button = Button.new()
	back.text = "Back"
	back.pressed.connect(func() -> void: show_inventory("Resources"))
	content.add_child(back)

func show_statistics() -> void:
	super.show_statistics()
	var history_button: Button = Button.new()
	history_button.text = "Activity History"
	history_button.pressed.connect(show_activity_history)
	content.add_child(history_button)


func _load_game_settings() -> void:
	if not FileAccess.file_exists(SETTINGS_PATH):
		_save_game_settings()
		return
	var file := FileAccess.open(SETTINGS_PATH, FileAccess.READ)
	if file == null:
		return
	var parsed = JSON.parse_string(file.get_as_text())
	file.close()
	if parsed is Dictionary:
		for key in game_settings:
			if parsed.has(key):
				game_settings[key] = parsed[key]

func _save_game_settings() -> void:
	var file := FileAccess.open(SETTINGS_PATH, FileAccess.WRITE)
	if file == null:
		return
	file.store_string(JSON.stringify(game_settings, "\t"))
	file.close()

func _apply_ui_scale() -> void:
	var ui_root := get_node_or_null("MainUIRoot") as Control
	if ui_root == null:
		return
	var scale_value := clampf(float(game_settings.get("ui_scale", 1.0)), 0.75, 1.75)
	# Keep the layout untransformed. Scale font metrics and minimum sizes so containers reflow.
	ui_root.scale = Vector2.ONE
	ui_root.pivot_offset = Vector2.ZERO
	if _ui_base_theme == null:
		_ui_base_theme = ui_root.theme if ui_root.theme != null else ThemeDB.get_default_theme()
		_ui_base_font_size = maxi(1, _ui_base_theme.default_font_size)
	var scaled_theme := _ui_base_theme.duplicate() as Theme
	scaled_theme.default_base_scale = scale_value
	scaled_theme.default_font_size = maxi(1, roundi(float(_ui_base_font_size) * scale_value))
	ui_root.theme = scaled_theme
	_scale_control_tree(ui_root, scale_value)
	if ui_root is Container:
		(ui_root as Container).queue_sort()
	ui_root.queue_redraw()

func _scale_control_tree(node: Node, scale_value: float) -> void:
	for child in node.get_children():
		if child is Control:
			var control := child as Control
			var control_id: int = control.get_instance_id()
			if not _ui_original_min_sizes.has(control_id):
				_ui_original_min_sizes[control_id] = control.custom_minimum_size
			var original_size: Vector2 = _ui_original_min_sizes[control_id]
			control.custom_minimum_size = original_size * scale_value
			if not _ui_original_font_sizes.has(control_id):
				_ui_original_font_sizes[control_id] = maxi(1, control.get_theme_font_size("font_size"))
			var original_font_size: int = int(_ui_original_font_sizes[control_id])
			control.add_theme_font_size_override("font_size", maxi(1, roundi(float(original_font_size) * scale_value)))
			if control is Container:
				(control as Container).queue_sort()
			control.queue_redraw()
		_scale_control_tree(child, scale_value)

func _apply_display_settings() -> void:
	var window: Window = get_window()
	if window == null:
		return
	var resolution_text := str(game_settings.get("resolution", "1280x720"))
	var parts := resolution_text.split("x")
	var target_size := Vector2i(1280, 720)
	if parts.size() == 2:
		var width := int(parts[0])
		var height := int(parts[1])
		if width >= 640 and height >= 480:
			target_size = Vector2i(width, height)

	# Window.size is ignored while in ordinary fullscreen. Apply the requested
	# size in windowed mode first, then use exclusive fullscreen so the selected
	# display mode can take effect instead of simply stretching to the desktop.
	window.mode = Window.MODE_WINDOWED
	window.borderless = false
	window.size = target_size
	window.min_size = Vector2i(640, 480)
	window.position = (DisplayServer.screen_get_size() - target_size) / 2
	if bool(game_settings.get("fullscreen", false)):
		window.mode = Window.MODE_EXCLUSIVE_FULLSCREEN
	else:
		window.mode = Window.MODE_WINDOWED

func _apply_fps_setting() -> void:
	Engine.max_fps = int(game_settings.get("fps_cap", 60))

func _format_setting_number(value: int) -> String:
	if not bool(game_settings.get("compact_numbers", false)):
		return str(value)
	if abs(value) >= 1000000:
		return "%.1fM" % (float(value) / 1000000.0)
	if abs(value) >= 1000:
		return "%.1fK" % (float(value) / 1000.0)
	return str(value)

func _confirmation_prompts_enabled() -> bool:
	return bool(game_settings.get("confirmation_prompts", true))

func _reduce_progress_animation() -> bool:
	return bool(game_settings.get("reduce_animations", false))

func show_settings() -> void:
	clear_content()
	heading("Settings")
	var intro := Label.new()
	intro.text = "Changes apply immediately and are saved automatically."
	intro.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	content.add_child(intro)

	_settings_section("Display")
	var fullscreen := CheckButton.new()
	fullscreen.text = "Fullscreen"
	fullscreen.button_pressed = bool(game_settings.get("fullscreen", false))
	fullscreen.toggled.connect(func(enabled: bool) -> void:
		game_settings["fullscreen"] = enabled
		_apply_display_settings()
		_save_game_settings()
	)
	content.add_child(fullscreen)
	var resolution_row := HBoxContainer.new()
	var resolution_label := Label.new()
	resolution_label.text = "Resolution"
	resolution_label.custom_minimum_size.x = 150
	resolution_row.add_child(resolution_label)
	var resolution := OptionButton.new()
	for option in ["1024x768", "1280x720", "1366x768", "1600x900", "1920x1080"]:
		resolution.add_item(option)
	var selected_resolution := str(game_settings.get("resolution", "1280x720"))
	for i in range(resolution.item_count):
		if resolution.get_item_text(i) == selected_resolution:
			resolution.select(i)
			break
	resolution.item_selected.connect(func(index: int) -> void:
		game_settings["resolution"] = resolution.get_item_text(index)
		_apply_display_settings()
		_save_game_settings()
	)
	resolution_row.add_child(resolution)
	content.add_child(resolution_row)

	_settings_section("Audio")
	_add_volume_control("Master volume", "Master", "master_volume")
	_add_volume_control("Music volume", "Music", "music_volume")
	_add_volume_control("Sound effects", "SFX", "sfx_volume")

	_settings_section("Gameplay")
	var number_row := HBoxContainer.new()
	var number_label := Label.new()
	number_label.text = "Number formatting"
	number_label.custom_minimum_size.x = 150
	number_row.add_child(number_label)
	var number_format := OptionButton.new()
	number_format.add_item("Standard (1,000)")
	number_format.add_item("Compact (1.0K)")
	number_format.select(1 if bool(game_settings.get("compact_numbers", false)) else 0)
	number_format.item_selected.connect(func(index: int) -> void:
		game_settings["compact_numbers"] = index == 1
		_save_game_settings()
		update_coins()
	)
	number_row.add_child(number_format)
	content.add_child(number_row)
	var confirmations := CheckButton.new()
	confirmations.text = "Confirm purchases and sales"
	confirmations.button_pressed = bool(game_settings.get("confirmation_prompts", true))
	confirmations.toggled.connect(func(enabled: bool) -> void:
		game_settings["confirmation_prompts"] = enabled
		_save_game_settings()
	)
	content.add_child(confirmations)

	_settings_section("Performance")
	var fps_row := HBoxContainer.new()
	var fps_label := Label.new()
	fps_label.text = "FPS cap"
	fps_label.custom_minimum_size.x = 150
	fps_row.add_child(fps_label)
	var fps := OptionButton.new()
	var fps_values: Array[int] = [30, 60, 90, 120, 144, 240, 0]
	var fps_labels: Array[String] = ["30 FPS", "60 FPS", "90 FPS", "120 FPS", "144 FPS", "240 FPS", "Unlimited"]
	for i in range(fps_values.size()):
		fps.add_item(fps_labels[i])
		if int(game_settings.get("fps_cap", 60)) == fps_values[i]:
			fps.select(i)
	fps.item_selected.connect(func(index: int) -> void:
		game_settings["fps_cap"] = fps_values[index]
		_apply_fps_setting()
		_save_game_settings()
	)
	fps_row.add_child(fps)
	content.add_child(fps_row)
	var reduce_motion := CheckButton.new()
	reduce_motion.text = "Reduce progress-bar animation"
	reduce_motion.button_pressed = bool(game_settings.get("reduce_animations", false))
	reduce_motion.toggled.connect(func(enabled: bool) -> void:
		game_settings["reduce_animations"] = enabled
		_save_game_settings()
	)
	content.add_child(reduce_motion)

	_settings_section("Text Size / UI Scale")
	var scale_label := Label.new()
	scale_label.text = "Entire interface: " + str(roundi(float(game_settings.get("ui_scale", 1.0)) * 100.0)) + "%"
	content.add_child(scale_label)
	var scale_slider := HSlider.new()
	scale_slider.min_value = 75
	scale_slider.max_value = 175
	scale_slider.step = 5
	scale_slider.value = float(game_settings.get("ui_scale", 1.0)) * 100.0
	scale_slider.custom_minimum_size.x = 300
	scale_slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scale_slider.value_changed.connect(func(value: float) -> void:
		game_settings["ui_scale"] = value / 100.0
		scale_label.text = "Entire interface: " + str(roundi(value)) + "%"
		_apply_ui_scale()
		_save_game_settings()
	)
	content.add_child(scale_slider)
	var scale_hint := Label.new()
	scale_hint.text = "Scales tabs, icons, buttons, spacing and text together. At high values, parts of the screen may need scrolling."
	scale_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	content.add_child(scale_hint)

	_settings_section("Data")
	var save_row := HBoxContainer.new()
	var save_button := Button.new()
	save_button.text = "Save Game Now"
	save_button.pressed.connect(func() -> void:
		save_game()
		status_label.text = "Game saved."
	)
	save_row.add_child(save_button)
	var export_button := Button.new()
	export_button.text = "Export Save"
	export_button.pressed.connect(_open_export_dialog)
	save_row.add_child(export_button)
	var import_button := Button.new()
	import_button.text = "Import Save"
	import_button.pressed.connect(_open_import_dialog)
	save_row.add_child(import_button)
	content.add_child(save_row)
	var reset_button := Button.new()
	reset_button.text = "Reset Progress..."
	reset_button.pressed.connect(_confirm_reset_progress)
	content.add_child(reset_button)

	_settings_section("About")
	var about := Label.new()
	about.text = "Milky Way: Offline\nVersion: " + str(ProjectSettings.get_setting("application/config/version", "0.1.0")) + "\nDesign and development: Arman Xtorin\nBuilt with Godot Engine."
	about.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	content.add_child(about)

func _settings_section(section_name: String) -> void:
	content.add_child(HSeparator.new())
	heading(section_name)

func _add_volume_control(label_text: String, bus_name: String, setting_key: String) -> void:
	var row := HBoxContainer.new()
	var label := Label.new()
	label.text = label_text
	label.custom_minimum_size.x = 150
	row.add_child(label)
	var slider := HSlider.new()
	slider.min_value = 0
	slider.max_value = 100
	slider.step = 1
	slider.value = float(game_settings.get(setting_key, 100.0))
	slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var bus_index := AudioServer.get_bus_index(bus_name)
	if bus_index < 0:
		slider.editable = false
		slider.tooltip_text = "No '" + bus_name + "' audio bus is configured in this project yet."
	else:
		slider.value_changed.connect(func(value: float) -> void:
			game_settings[setting_key] = value
			if value <= 0.0:
				AudioServer.set_bus_mute(bus_index, true)
			else:
				AudioServer.set_bus_mute(bus_index, false)
				AudioServer.set_bus_volume_db(bus_index, linear_to_db(value / 100.0))
			_save_game_settings()
		)
	row.add_child(slider)
	if bus_index < 0:
		var missing := Label.new()
		missing.text = "Not configured"
		missing.add_theme_font_size_override("font_size", 12)
		row.add_child(missing)
	content.add_child(row)
	if bus_index >= 0:
		var linear_volume := float(game_settings.get(setting_key, 100.0)) / 100.0
		AudioServer.set_bus_mute(bus_index, linear_volume <= 0.0)
		if linear_volume > 0.0:
			AudioServer.set_bus_volume_db(bus_index, linear_to_db(linear_volume))

func _open_export_dialog() -> void:
	save_game()
	_settings_file_dialog = FileDialog.new()
	_settings_file_dialog.file_mode = FileDialog.FILE_MODE_SAVE_FILE
	_settings_file_dialog.access = FileDialog.ACCESS_FILESYSTEM
	_settings_file_dialog.add_filter("*.json ; Milky Way save file")
	_settings_file_dialog.current_file = "milky_way_save.json"
	_settings_file_dialog.file_selected.connect(_export_save_to_path)
	add_child(_settings_file_dialog)
	_settings_file_dialog.popup_centered_ratio(0.75)

func _export_save_to_path(path: String) -> void:
	save_game()
	var source := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if source == null:
		status_label.text = "Could not read the current save."
		_cleanup_settings_file_dialog()
		return
	var data_text := source.get_as_text()
	source.close()
	var target := FileAccess.open(path, FileAccess.WRITE)
	if target == null:
		status_label.text = "Could not write the export file."
	else:
		target.store_string(data_text)
		target.close()
		status_label.text = "Save exported successfully."
	_cleanup_settings_file_dialog()

func _open_import_dialog() -> void:
	_settings_file_dialog = FileDialog.new()
	_settings_file_dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILE
	_settings_file_dialog.access = FileDialog.ACCESS_FILESYSTEM
	_settings_file_dialog.add_filter("*.json ; Milky Way save file")
	_settings_file_dialog.file_selected.connect(_import_save_from_path)
	add_child(_settings_file_dialog)
	_settings_file_dialog.popup_centered_ratio(0.75)

func _import_save_from_path(path: String) -> void:
	var source := FileAccess.open(path, FileAccess.READ)
	if source == null:
		status_label.text = "Could not read that file."
		_cleanup_settings_file_dialog()
		return
	var text_data := source.get_as_text()
	source.close()
	var parsed = JSON.parse_string(text_data)
	if not parsed is Dictionary or not parsed.has("coins") or not parsed.has("inventory"):
		status_label.text = "Invalid save file. Your current progress was not changed."
		_cleanup_settings_file_dialog()
		return
	var target := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if target == null:
		status_label.text = "Could not replace the save file."
		_cleanup_settings_file_dialog()
		return
	target.store_string(text_data)
	target.close()
	_cleanup_settings_file_dialog()
	get_tree().reload_current_scene()

func _confirm_reset_progress() -> void:
	var confirm := ConfirmationDialog.new()
	confirm.title = "Reset Progress"
	confirm.dialog_text = "Permanently erase this game's saved progress? This cannot be undone. Export your save first if you want a backup."
	confirm.confirmed.connect(func() -> void:
		if FileAccess.file_exists(SAVE_PATH):
			DirAccess.remove_absolute(ProjectSettings.globalize_path(SAVE_PATH))
		confirm.queue_free()
		get_tree().reload_current_scene()
	)
	confirm.canceled.connect(confirm.queue_free)
	add_child(confirm)
	confirm.popup_centered(Vector2i(480, 180))

func _cleanup_settings_file_dialog() -> void:
	if is_instance_valid(_settings_file_dialog):
		_settings_file_dialog.queue_free()
		_settings_file_dialog = null

func _request_action_confirmation(title_text: String, message_text: String, action: Callable) -> void:
	var confirm := ConfirmationDialog.new()
	confirm.title = title_text
	confirm.dialog_text = message_text
	confirm.confirmed.connect(func() -> void:
		action.call()
		confirm.queue_free()
	)
	confirm.canceled.connect(confirm.queue_free)
	add_child(confirm)
	confirm.popup_centered()
