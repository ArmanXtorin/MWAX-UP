extends "res://scripts/main_features.gd"

# Blacksmith repair layer.
# Keeps the existing feature systems untouched and restores working
# Blacksmith item selection, recipes, crafting, and tier unlocking.

func show_blacksmith_legacy2() -> void:
	clear_content()
	var safe_tier: int = clamp(unlocked_tier, 0, TIER_NAMES.size() - 1)
	heading("Blacksmith - " + TIER_NAMES[safe_tier] + " Tier")

	var info: Label = Label.new()
	info.text = "Select an item to see its recipe and crafting time."
	content.add_child(info)

	for raw_item_type in EQUIPMENT_TYPES:
		var item_type: String = str(raw_item_type)
		var button: Button = Button.new()
		button.text = TIER_NAMES[safe_tier] + " " + item_type
		button.custom_minimum_size = Vector2(260, 42)
		button.pressed.connect(_blacksmith_item_pressed.bind(safe_tier, item_type))
		content.add_child(button)

func _blacksmith_item_pressed(tier: int, item_type: String) -> void:
	var recipe: Dictionary = get_recipe(tier, item_type)
	show_recipe(recipe)

func get_recipe(tier: int, item_type: String) -> Dictionary:
	var safe_tier: int = clamp(tier, 0, TIER_NAMES.size() - 1)
	var materials: Dictionary = {}
	var amount: int = 10

	match item_type:
		"Sword", "Mace", "Shield":
			amount = 12
		"Helmet", "Knee Armor":
			amount = 8
		"Body Armor":
			amount = 16
		"Leg Armor":
			amount = 14
		_:
			amount = 10

	var wood_name: String = WOOD_NAMES[0] if safe_tier == 0 else WOOD_NAMES[safe_tier - 1]
	materials[wood_name] = amount

	if safe_tier > 0:
		var resource_name: String = str(RESOURCE_NAMES[safe_tier - 1])
		materials[resource_name] = amount

	return {
		"name": TIER_NAMES[safe_tier] + " " + item_type,
		"time": TIER_TIMES[safe_tier],
		"materials": materials
	}

func show_recipe(recipe: Dictionary) -> void:
	clear_content()
	heading(str(recipe.get("name", "Recipe")))

	var time_label: Label = Label.new()
	time_label.text = "Crafting time: " + str(recipe.get("time", 0.0)) + " seconds"
	content.add_child(time_label)

	var req_title: Label = Label.new()
	req_title.text = "REQUIRED MATERIALS (You have / Need)"
	content.add_child(req_title)

	var can_craft: bool = true
	var materials: Dictionary = recipe.get("materials", {})
	for key in materials:
		var need: int = int(materials[key])
		if need <= 0:
			continue
		var have: int = int(inventory.get(key, 0))
		var label: Label = Label.new()
		label.text = str(key) + ": " + str(have) + " / " + str(need)
		content.add_child(label)
		if have < need:
			can_craft = false

	var result: Label = Label.new()
	result.text = "RESULT: +1 " + str(recipe.get("name", "Item"))
	content.add_child(result)

	var once: Button = Button.new()
	once.text = "Craft Once"
	once.disabled = not can_craft
	once.pressed.connect(_craft_recipe_pressed.bind(recipe, "one"))
	content.add_child(once)

	var infinite: Button = Button.new()
	infinite.text = "Craft Infinite (until materials run out)"
	infinite.disabled = not can_craft
	infinite.pressed.connect(_craft_recipe_pressed.bind(recipe, "infinite"))
	content.add_child(infinite)

	var back: Button = Button.new()
	back.text = "Back"
	back.pressed.connect(show_blacksmith)
	content.add_child(back)

func _craft_recipe_pressed(recipe: Dictionary, mode: String) -> void:
	ask_craft_mode(recipe, mode)

func check_tier_unlock() -> void:
	if unlocked_tier >= TIER_NAMES.size() - 1:
		return

	var current_tier: int = unlocked_tier
	for raw_item_type in EQUIPMENT_TYPES:
		var item_type: String = str(raw_item_type)
		var item_name: String = TIER_NAMES[current_tier] + " " + item_type
		if int(inventory.get(item_name, 0)) <= 0:
			return

	unlocked_tier += 1
	status_label.text = "Tier completed! " + TIER_NAMES[unlocked_tier] + " Tier unlocked!"
	show_blacksmith()

func show_token_store() -> void:
	clear_content()
	heading("Token Store")

	var balance: Label = Label.new()
	balance.text = "Quest Tokens: " + str(quest_tokens)
	content.add_child(balance)

	var subtitle: Label = Label.new()
	subtitle.text = "Spend Quest Tokens on temporary potions."
	content.add_child(subtitle)

	for raw_potion_name in POTIONS.keys():
		var potion_name: String = str(raw_potion_name)
		var data: Dictionary = POTIONS[potion_name]

		var row: HBoxContainer = HBoxContainer.new()
		row.custom_minimum_size = Vector2(0, 44)

		var label: Label = Label.new()
		label.text = potion_name + " - " + str(data["effect"]) + " - " + str(data["cost"]) + " Tokens"
		label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(label)

		var buy: Button = Button.new()
		buy.text = "Buy"
		buy.custom_minimum_size = Vector2(100, 40)
		buy.disabled = quest_tokens < int(data["cost"])
		buy.pressed.connect(_token_store_buy_pressed.bind(potion_name))
		row.add_child(buy)

		content.add_child(row)

func _token_store_buy_pressed(potion_name: String) -> void:
	buy_potion(potion_name)

# === NEW PROGRESSION INTEGRATION ===
const NEW_SKILL_REQUIREMENTS := {"Wooden":5,"Stone":15,"Copper":25,"Iron":30,"Golden":50,"Diamond":75}
const NEW_TOOL_TYPES := ["Pickaxe","Axe","Hammer"]
const NEW_TOOL_SKILLS := {"Pickaxe":"Mining","Axe":"Woodcutting","Hammer":"Blacksmithing"}
const NEW_SMELT_YIELDS := {"Copper":"Pure Copper","Iron":"Pure Iron","Gold":"Pure Gold","Diamond":"Pure Diamond"}
var skill_levels: Dictionary = {"Mining":1,"Woodcutting":1,"Blacksmithing":1}
var tool_progression: Dictionary = {"Pickaxe":-1,"Axe":-1,"Hammer":-1}
var pure_materials: Dictionary = {}
var _new_ui_built := false

func _skill_bar_bounds(skill:String, level:int) -> Array[int]:
	var milestones:Array[int] = [1, 5, 15, 25, 30, 50, 75]
	var previous:int = 1
	var next:int = 5
	for milestone in milestones:
		if level < milestone:
			next = milestone
			break
		previous = milestone
		if milestone == milestones[-1]:
			next = milestone + 25
	return [previous, next]

func _update_skill_bars(animate: bool = false) -> void:
	for skill in ["Mining", "Woodcutting", "Blacksmithing"]:
		var level:int = int(skill_levels.get(skill, 1))
		var bar:ProgressBar = find_child("SkillBar_" + skill, true, false) as ProgressBar
		var label:Label = find_child("SkillLabel_" + skill, true, false) as Label
		if bar == null or label == null:
			continue
		var bounds:Array[int] = _skill_bar_bounds(skill, level)
		var previous:int = bounds[0]
		var next:int = bounds[1]
		bar.min_value = previous
		bar.max_value = next
		var target:float = clamp(float(level), float(previous), float(next))
		if animate:
			var tween:Tween = create_tween()
			tween.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
			tween.tween_property(bar, "value", target, 0.45)
		else:
			bar.value = target
		label.text = skill + " Lv. " + str(level)

func _new_tier_name(t:int)->String: return TIER_NAMES[clamp(t,0,TIER_NAMES.size()-1)]
func _new_skill(tool:String)->String: return str(NEW_TOOL_SKILLS[tool])
func _new_skill_level(skill:String)->int: return int(skill_levels.get(skill,1))
func _gain_new_skill(skill:String, amount:int=1)->void:
	skill_levels[skill]=int(skill_levels.get(skill,1))+amount
	_update_skill_bars(true)
func _new_tool_req(tool:String,tier:int)->bool: return int(skill_levels.get(_new_skill(tool),1)) >= int(NEW_SKILL_REQUIREMENTS[_new_tier_name(tier)])
func _new_recipe(tool:String,tier:int)->Dictionary:
	var m:Dictionary={}
	var tn:=_new_tier_name(tier)
	var wood_name:String = WOOD_NAMES[clamp(tier - 1,0,WOOD_NAMES.size()-1)]
	m[wood_name]=1
	if tier==1: m["Stone"]=1
	elif tier>=2: m["Pure "+("Gold" if tn=="Golden" else tn)]=1
	if tier>0: m[_new_tier_name(tier-1)+" "+tool]=1
	return {"name":tn+" "+tool,"materials":m}
func _new_can(m:Dictionary)->bool:
	for k in m: if int(inventory.get(k,0))<int(m[k]): return false
	return true
func _new_consume(m:Dictionary)->void:
	for k in m: inventory[k]=int(inventory.get(k,0))-int(m[k])

func show_blacksmith() -> void:
	clear_content(); heading("Blacksmith")
	var xp:=Label.new(); xp.text="Blacksmithing Lv. "+str(skill_levels["Blacksmithing"])+"   |   Hammer progression"; content.add_child(xp)
	for tool in NEW_TOOL_TYPES:
		var tier:=int(tool_progression[tool]); var row:=VBoxContainer.new()
		var current_name:String = "None" if tier < 0 else _new_tier_name(tier)
		var l:=Label.new(); l.text=tool+": "+current_name+" | "+_new_skill(tool)+" Lv. "+str(skill_levels[_new_skill(tool)]); row.add_child(l)
		var next_tier:int = tier + 1
		if next_tier < TIER_NAMES.size():
			var next:=_new_tier_name(next_tier); var b:=Button.new(); b.text="Craft "+next+" "+tool+" (requires Lv. "+str(NEW_SKILL_REQUIREMENTS[next])+")"; b.disabled=not _new_tool_req(tool,next_tier) or not _new_can(_new_recipe(tool,next_tier)["materials"]); b.pressed.connect(_new_craft_tool.bind(tool,next_tier)); row.add_child(b)
		content.add_child(row); content.add_child(HSeparator.new())
	var sm:=Button.new(); sm.text="Open Smelting"; sm.pressed.connect(show_smelting); content.add_child(sm)

func _new_craft_tool(tool:String,tier:int)->void:
	var r:=_new_recipe(tool,tier); if not _new_tool_req(tool,tier) or not _new_can(r["materials"]): return
	_new_consume(r["materials"]); var name:=str(r["name"]); inventory[name]=int(inventory.get(name,0))+1; crafted_equipment[name]=true; tool_progression[tool]=tier; _gain_new_skill(_new_skill(tool)); status_label.text=name+" crafted."; save_game(); show_blacksmith()

func show_smelting()->void:
	clear_content(); heading("Smelting")
	var info:=Label.new(); info.text="Ore -> Pure Material | Blacksmithing XP +1"; content.add_child(info)
	for ore in NEW_SMELT_YIELDS:
		var pure:=str(NEW_SMELT_YIELDS[ore]); var row:=HBoxContainer.new(); var l:=Label.new(); l.text=ore+" -> "+pure+" | Have: "+str(inventory.get(ore,0)); l.size_flags_horizontal=Control.SIZE_EXPAND_FILL; row.add_child(l); var b:=Button.new(); b.text="Smelt 1"; b.disabled=int(inventory.get(ore,0))<1; b.pressed.connect(_new_smelt.bind(ore)); row.add_child(b); content.add_child(row)

func _new_smelt(ore:String)->void:
	if int(inventory.get(ore,0))<1:return
	inventory[ore]=int(inventory.get(ore,0))-1; var p:=str(NEW_SMELT_YIELDS[ore]); inventory[p]=int(inventory.get(p,0))+1; pure_materials[p]=int(pure_materials.get(p,0))+1; _gain_new_skill("Blacksmithing"); status_label.text="Smelted "+ore+" into "+p; save_game(); show_smelting()

func show_inventory(tab:String)->void:
	if tab=="Equipment": clear_content(); heading("Equipment"); _show_new_equipment(); return
	super.show_inventory(tab)
func _show_new_equipment()->void:
	for tool in NEW_TOOL_TYPES:
		var t:=int(tool_progression[tool]); var tool_name:String = "None" if t < 0 else _new_tier_name(t)+" "+str(tool); var l:=Label.new(); l.text=str(tool)+": "+tool_name+" | Skill Lv. "+str(skill_levels[_new_skill(tool)]); content.add_child(l)

func save_game()->void:
	super.save_game(); var f:=FileAccess.open(SAVE_PATH,FileAccess.READ); if f==null:return; var d=JSON.parse_string(f.get_as_text()); f.close(); if d is Dictionary: d["skill_levels"]=skill_levels; d["tool_progression"]=tool_progression; d["pure_materials"]=pure_materials; f=FileAccess.open(SAVE_PATH,FileAccess.WRITE); f.store_string(JSON.stringify(d)); f.close()

func _load_new()->void:
	if not FileAccess.file_exists(SAVE_PATH):return
	var f:=FileAccess.open(SAVE_PATH,FileAccess.READ); var d=JSON.parse_string(f.get_as_text()); f.close(); if d is Dictionary:
		var saved_skills: Variant = d.get("skill_levels", {})
		if saved_skills is Dictionary:
			for k in saved_skills:
				skill_levels[str(k)] = int(saved_skills[k])
		var saved_tools: Variant = d.get("tool_progression", {})
		if saved_tools is Dictionary:
			for k in saved_tools:
				var loaded_tool:String = str(k)
				var loaded_tier:int = int(saved_tools[k])
				if loaded_tier == 0 and int(inventory.get("Wooden " + loaded_tool, 0)) <= 0:
					loaded_tier = -1
				tool_progression[loaded_tool] = loaded_tier
		var saved_pure: Variant = d.get("pure_materials", {})
		if saved_pure is Dictionary:
			for k in saved_pure:
				pure_materials[str(k)] = int(saved_pure[k])
				inventory[str(k)] = int(saved_pure[k])

func _ready_new_features()->void:
	for item in RESOURCE_NAMES + WOOD_NAMES:
		if not inventory.has(item): inventory[item]=0
	for p in NEW_SMELT_YIELDS.values(): pure_materials[str(p)]=int(inventory.get(str(p),0))
	_load_new()
	unlocked_tier=0
	_update_skill_bars()

func _ready() -> void:
	super._ready()
	_ready_new_features()
	_apply_runtime_ui_safety()

func _apply_runtime_ui_safety() -> void:
	if has_node("Content"):
		var c=get_node("Content")
		c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		c.custom_minimum_size=Vector2(0,0)
		c.size_flags_horizontal=Control.SIZE_EXPAND_FILL
		c.size_flags_vertical=Control.SIZE_EXPAND_FILL
