# Milky Way

Godot 4 prototype for Android and PC.

## Included
- Mining
- Woodcutting
- Blacksmith
- Shop
- Food page
- Inventory
- Starting coins: 0
- Unlimited inventory
- Cancellable gathering operations
- One active operation at a time
- Unfinished crafting is cancelled when the game closes

## Project structure
- `project.godot`
- `scenes/main.tscn`
- `scripts/main.gd`

Open the `Milky Way` folder as a project in Godot 4.x.
