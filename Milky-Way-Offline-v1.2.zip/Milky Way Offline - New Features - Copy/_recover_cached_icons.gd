extends SceneTree
func _initialize():
 call_deferred("recover")
func recover():
 var base="res://RECOVERY_SNAPSHOT_icons_20261011_214725/cache_recovered/"
 var dir=DirAccess.open(base)
 print("DIR "+str(dir))
 if dir==null:
  quit(1)
 dir.list_dir_begin()
 var f=dir.get_next()
 while f!="":
  if f.ends_with(".ctex"):
   var t=ResourceLoader.load(base+f)
   if t is Texture2D:
    var im=t.get_image()
    var out="res://RECOVERY_SNAPSHOT_icons_20261011_214725/"+f.replace(".ctex", ".png")
    var e=im.save_png(out)
    print(f+" => "+str(e)+" "+str(im.get_size()))
   else:
    print("NOT_TEXTURE "+f+" "+str(t))
  f=dir.get_next()
 dir.list_dir_end()
 quit()
