extends SceneTree
func _initialize() -> void:
 var report := ""
 for p in [
  "res://assets/icons/mining.svg",
  "res://assets/icons/woodcutting.svg",
  "res://assets/icons/items/copper.svg",
  "res://assets/icons/items/pickaxe.svg",
  "res://assets/icons/items/axe.svg",
  "res://assets/icons/items/hammer.svg",
  "res://assets/icons/items/pure_copper.svg",
  "res://assets/icons/items/pure_iron.svg",
  "res://assets/icons/items/pure_gold.svg",
  "res://assets/icons/items/pure_diamond.svg"
 ]:
  var r = load(p)
  report += p + " => " + ("NULL" if r == null else r.get_class()) + "\n"
 var f := FileAccess.open("C:/Users/Arman Xtorin/Desktop/Milky Way Offline - New Features/_icon_test_result.txt", FileAccess.WRITE)
 if f:
  f.store_string(report)
 quit()
